-- ============================================================
-- SMM Panel - Cloudflare D1 Database Schema
-- Version: 1.0.0
-- ============================================================

-- Drop tables if exist (for fresh setup)
DROP TABLE IF EXISTS force_channels;
DROP TABLE IF EXISTS banners;
DROP TABLE IF EXISTS announcements;
DROP TABLE IF EXISTS settings;
DROP TABLE IF EXISTS referrals;
DROP TABLE IF EXISTS transactions;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS services;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS admins;
DROP TABLE IF EXISTS users;

-- ============================================================
-- USERS TABLE
-- ============================================================
CREATE TABLE users (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  tg_id        TEXT    NOT NULL UNIQUE,
  first_name   TEXT    NOT NULL DEFAULT '',
  last_name    TEXT    NOT NULL DEFAULT '',
  username     TEXT    NOT NULL DEFAULT '',
  photo_url    TEXT    NOT NULL DEFAULT '',
  balance      REAL    NOT NULL DEFAULT 0,
  total_spent  REAL    NOT NULL DEFAULT 0,
  total_orders INTEGER NOT NULL DEFAULT 0,
  status       TEXT    NOT NULL DEFAULT 'active', -- active | blocked
  blocked_msg  TEXT    NOT NULL DEFAULT '',
  referral_code TEXT   NOT NULL DEFAULT '',
  referred_by  TEXT    NOT NULL DEFAULT '',
  last_join_check INTEGER NOT NULL DEFAULT 0,     -- unix timestamp
  created_at   INTEGER NOT NULL DEFAULT (strftime('%s','now')),
  updated_at   INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

CREATE INDEX idx_users_tg_id ON users(tg_id);
CREATE INDEX idx_users_referral_code ON users(referral_code);

-- ============================================================
-- ADMINS TABLE
-- ============================================================
CREATE TABLE admins (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  tg_id      TEXT    NOT NULL UNIQUE,
  username   TEXT    NOT NULL DEFAULT '',
  name       TEXT    NOT NULL DEFAULT '',
  role       TEXT    NOT NULL DEFAULT 'admin',   -- superadmin | admin
  status     TEXT    NOT NULL DEFAULT 'active',
  created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

-- ============================================================
-- CATEGORIES TABLE
-- ============================================================
CREATE TABLE categories (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  name         TEXT    NOT NULL,
  platform_key TEXT    NOT NULL DEFAULT 'all',   -- facebook|youtube|tiktok|instagram|telegram|twitter|x|all
  icon         TEXT    NOT NULL DEFAULT '',
  sort_order   INTEGER NOT NULL DEFAULT 0,
  status       TEXT    NOT NULL DEFAULT 'active', -- active | hidden
  created_at   INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

CREATE INDEX idx_categories_platform ON categories(platform_key);
CREATE INDEX idx_categories_status ON categories(status);

-- ============================================================
-- SERVICES TABLE
-- ============================================================
CREATE TABLE services (
  id                     INTEGER PRIMARY KEY AUTOINCREMENT,
  category_id            INTEGER NOT NULL REFERENCES categories(id),
  name                   TEXT    NOT NULL,
  description            TEXT    NOT NULL DEFAULT '',
  rate_per_1000          REAL    NOT NULL DEFAULT 0,
  min_qty                INTEGER NOT NULL DEFAULT 100,
  max_qty                INTEGER NOT NULL DEFAULT 100000,
  service_type           TEXT    NOT NULL DEFAULT 'default',  -- default | custom_comments | mentions
  needs_custom_comments  INTEGER NOT NULL DEFAULT 0,           -- 0 | 1
  visible_service_id     TEXT    NOT NULL DEFAULT '',          -- display ID for users
  provider_service_id    TEXT    NOT NULL DEFAULT '',          -- external API service ID
  avg_time               TEXT    NOT NULL DEFAULT '',          -- e.g. "1-2 hours"
  sort_order             INTEGER NOT NULL DEFAULT 0,
  status                 TEXT    NOT NULL DEFAULT 'active',    -- active | hidden
  created_at             INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

CREATE INDEX idx_services_category ON services(category_id);
CREATE INDEX idx_services_status ON services(status);

-- ============================================================
-- ORDERS TABLE
-- ============================================================
CREATE TABLE orders (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id          INTEGER NOT NULL REFERENCES users(id),
  service_id       INTEGER NOT NULL REFERENCES services(id),
  link             TEXT    NOT NULL,
  quantity         INTEGER NOT NULL,
  charge           REAL    NOT NULL,
  custom_comments  TEXT    NOT NULL DEFAULT '',
  status           TEXT    NOT NULL DEFAULT 'pending', -- pending | processing | completed | partial | cancelled | refunded
  provider_order_id TEXT   NOT NULL DEFAULT '',
  start_count      INTEGER NOT NULL DEFAULT 0,
  remains          INTEGER NOT NULL DEFAULT 0,
  note             TEXT    NOT NULL DEFAULT '',
  created_at       INTEGER NOT NULL DEFAULT (strftime('%s','now')),
  updated_at       INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

CREATE INDEX idx_orders_user ON orders(user_id);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_orders_created ON orders(created_at);

-- ============================================================
-- TRANSACTIONS TABLE
-- ============================================================
CREATE TABLE transactions (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id     INTEGER NOT NULL REFERENCES users(id),
  type        TEXT    NOT NULL,   -- deposit | order_charge | refund | referral_bonus | admin_add | admin_remove
  amount      REAL    NOT NULL,
  balance_before REAL NOT NULL DEFAULT 0,
  balance_after  REAL NOT NULL DEFAULT 0,
  reference   TEXT    NOT NULL DEFAULT '', -- order_id / deposit_id etc
  note        TEXT    NOT NULL DEFAULT '',
  status      TEXT    NOT NULL DEFAULT 'completed',
  created_at  INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

CREATE INDEX idx_transactions_user ON transactions(user_id);
CREATE INDEX idx_transactions_type ON transactions(type);

-- ============================================================
-- REFERRALS TABLE
-- ============================================================
CREATE TABLE referrals (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  referrer_id  INTEGER NOT NULL REFERENCES users(id),
  referred_id  INTEGER NOT NULL REFERENCES users(id),
  bonus_amount REAL    NOT NULL DEFAULT 0,
  status       TEXT    NOT NULL DEFAULT 'active',
  created_at   INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

CREATE INDEX idx_referrals_referrer ON referrals(referrer_id);

-- ============================================================
-- SETTINGS TABLE
-- ============================================================
CREATE TABLE settings (
  key        TEXT PRIMARY KEY,
  value      TEXT NOT NULL DEFAULT '',
  updated_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

-- Default settings
INSERT INTO settings (key, value) VALUES
  ('site_name',           'SMM Panel'),
  ('currency_symbol',     '৳'),
  ('referral_bonus',      '10'),
  ('min_deposit',         '50'),
  ('maintenance_mode',    '0'),
  ('maintenance_msg',     'We are under maintenance. Please check back later.'),
  ('running_text',        'Welcome to SMM Panel! Get the best SMM services at the lowest prices. 🚀'),
  ('admin_contact',       'https://t.me/admin'),
  ('bot_token',           ''),
  ('bot_username',        ''),
  ('referral_enabled',    '1'),
  ('deposit_enabled',     '1'),
  ('order_enabled',       '1');

-- ============================================================
-- ANNOUNCEMENTS TABLE
-- ============================================================
CREATE TABLE announcements (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  title      TEXT    NOT NULL,
  content    TEXT    NOT NULL,
  type       TEXT    NOT NULL DEFAULT 'info',  -- info | warning | success | danger
  status     TEXT    NOT NULL DEFAULT 'active', -- active | hidden
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

-- ============================================================
-- BANNERS TABLE (Slider)
-- ============================================================
CREATE TABLE banners (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  title      TEXT    NOT NULL DEFAULT '',
  image_url  TEXT    NOT NULL,
  link_url   TEXT    NOT NULL DEFAULT '',
  sort_order INTEGER NOT NULL DEFAULT 0,
  status     TEXT    NOT NULL DEFAULT 'active',
  created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

-- ============================================================
-- FORCE CHANNELS TABLE
-- ============================================================
CREATE TABLE force_channels (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  title            TEXT    NOT NULL,
  channel_username TEXT    NOT NULL,  -- @username
  channel_id       TEXT    NOT NULL,  -- -100xxxxx
  invite_link      TEXT    NOT NULL DEFAULT '',
  sort_order       INTEGER NOT NULL DEFAULT 0,
  status           TEXT    NOT NULL DEFAULT 'active',
  created_at       INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

-- ============================================================
-- Sample Data
-- ============================================================

-- Sample Categories
INSERT INTO categories (name, platform_key, sort_order) VALUES
  ('Facebook Likes',      'facebook',  1),
  ('Facebook Followers',  'facebook',  2),
  ('Instagram Followers', 'instagram', 3),
  ('Instagram Likes',     'instagram', 4),
  ('YouTube Views',       'youtube',   5),
  ('YouTube Subscribers', 'youtube',   6),
  ('TikTok Followers',    'tiktok',    7),
  ('Telegram Members',    'telegram',  8),
  ('Twitter Followers',   'twitter',   9);

-- Sample Services
INSERT INTO services (category_id, name, description, rate_per_1000, min_qty, max_qty, visible_service_id, avg_time, sort_order) VALUES
  (1, 'Facebook Page Likes [Real]',       'High quality real Facebook page likes. Fast delivery guaranteed.',    15.00, 100, 50000,  'S001', '1-2 hours',  1),
  (1, 'Facebook Page Likes [HQ]',         'High quality Facebook page likes with fast delivery.',                12.00, 500, 100000, 'S002', '30 min',     2),
  (2, 'Facebook Profile Followers',       'Real looking Facebook profile followers.',                            18.00, 100, 10000,  'S003', '2-3 hours',  1),
  (3, 'Instagram Followers [Real]',       'Premium quality Instagram followers. Non-drop guarantee.',            25.00, 100, 50000,  'S004', '1-6 hours',  1),
  (3, 'Instagram Followers [Fast]',       'Super fast Instagram followers delivery.',                            20.00, 100, 100000, 'S005', '10-30 min',  2),
  (4, 'Instagram Post Likes',             'Real Instagram post likes with fast delivery.',                       10.00, 50,  100000, 'S006', '5-10 min',   1),
  (5, 'YouTube Views [HQ]',              'High retention YouTube views. Safe and effective.',                    30.00, 500, 500000, 'S007', '24-48 hours',1),
  (6, 'YouTube Subscribers [Real]',       'Real YouTube channel subscribers.',                                   50.00, 100, 10000,  'S008', '1-2 days',   1),
  (7, 'TikTok Followers',                'Real TikTok followers with fast delivery.',                           22.00, 100, 50000,  'S009', '1-3 hours',  1),
  (8, 'Telegram Channel Members',         'Real Telegram channel members.',                                      35.00, 100, 100000, 'S010', '1-6 hours',  1),
  (9, 'Twitter/X Followers',              'Real Twitter/X followers.',                                           28.00, 100, 50000,  'S011', '2-4 hours',  1);

-- Sample Banner
INSERT INTO banners (title, image_url, link_url, sort_order) VALUES
  ('Welcome Offer',   'https://placehold.co/540x304/2563eb/ffffff?text=Welcome+to+SMM+Panel', '#', 1),
  ('New Services',    'https://placehold.co/540x304/0ea5e9/ffffff?text=New+Services+Added',   '#', 2),
  ('Refer & Earn',    'https://placehold.co/540x304/7c3aed/ffffff?text=Refer+and+Earn+Bonus', '#', 3);

-- Sample Announcement
INSERT INTO announcements (title, content, type, sort_order) VALUES
  ('Welcome! 🎉', 'Get the best SMM services at the lowest prices. New users get a referral bonus!', 'info', 1),
  ('Fast Delivery', 'All orders are processed within 24 hours. 🚀 Place your order now!', 'success', 2);

-- Sample Force Channel
INSERT INTO force_channels (title, channel_username, channel_id, invite_link, sort_order) VALUES
  ('SMM Panel Official', '@smmchannel', '-1001234567890', 'https://t.me/smmchannel', 1);
