/**
 * config.js — Shared frontend configuration
 * SMM Panel v1.0.0
 *
 * Edit this file to customise panel-wide settings.
 * All values here are public (client-visible). Never put secrets here.
 */

const SMM_CONFIG = {
  // Panel identity
  PANEL_NAME:       'SMM Panel',
  CURRENCY_SYMBOL:  '৳',
  VERSION:          '1.0.0',

  // API base (empty = same origin; set to Worker URL when using Cloudflare Pages)
  // Example: 'https://smm-panel.yourname.workers.dev'
  API_BASE:   '',

  // Telegram Bot username (without @)
  BOT_USERNAME: 'YourBotUsername',

  // Navigation pages
  PAGES: {
    home:    '/index.html',
    orders:  '/orders.html',
    deposit: '/deposit.html',
    profile: '/profile.html',
    admin:   '/admin.html',
  },

  // Feature flags (override by /api/settings at runtime)
  FEATURES: {
    referral:  true,
    deposit:   true,
    ordering:  true,
    chat:      false,
  },

  // UI
  THEME: {
    primary:   '#2563eb',
    secondary: '#0ea5e9',
    accent:    '#7c3aed',
    danger:    '#ef4444',
    success:   '#22c55e',
  },

  // Request timeouts (ms)
  TIMEOUT: 15000,

  // Slider auto-play interval (ms)
  SLIDER_INTERVAL: 4000,
};

// Make available globally
if (typeof window !== 'undefined') {
  window.SMM_CONFIG = SMM_CONFIG;
}

if (typeof module !== 'undefined') {
  module.exports = SMM_CONFIG;
}
