# 🚀 SMM Panel — Cloudflare Workers + D1

A fully-featured **Social Media Marketing (SMM) Panel** built as a **Telegram WebApp**, powered by **Cloudflare Workers** (serverless backend) and **Cloudflare D1** (SQLite database). Zero server cost, globally distributed, production-ready.

---

## ✨ Features

### User Panel
| Feature | Description |
|---|---|
| 🔐 Telegram Login | Secure HMAC-verified initData authentication |
| 💰 Balance System | Real-time balance display with transaction history |
| 📦 New Order | Platform & category filters, live service search, price calculator |
| 📋 Order History | Status filters, pagination, live badge indicators |
| 💳 Deposit | Multiple payment methods (bKash, Nagad, Rocket, USDT) |
| 🎁 Referral | Unique referral links, bonus tracking, share button |
| 📢 Announcements | Live marquee ticker + notification cards |
| 🖼️ Banner Slider | Auto-play image slider with dot navigation |
| 🔒 Force Join | Telegram channel membership gate with auto-check |
| 👤 Profile | Stats, account info, recent transactions |

### Admin Panel
| Feature | Description |
|---|---|
| 📊 Dashboard | Live stats, recent orders table |
| 👥 Users | Search, balance add/remove, block/unblock |
| 📦 Orders | Filter by status, update order status, auto-refund |
| 🗂️ Categories | Full CRUD, platform mapping, sort order |
| ⚙️ Services | Full CRUD, pricing, min/max qty, service types |
| 🖼️ Banners | Image URL banners, link, sort order |
| 📢 Announcements | Title, content, type (info/success/warning/danger) |
| 📺 Force Channels | Add/remove Telegram channels users must join |
| ⚙️ Settings | Site name, bot token, referral bonus, feature flags |

---

## 🗂️ Project Structure

```
smm-panel/
├── public/                  ← Static files (Cloudflare Pages)
│   ├── index.html           ← Main order page (Telegram WebApp)
│   ├── orders.html          ← Order history page
│   ├── deposit.html         ← Deposit / top-up page
│   ├── profile.html         ← Profile & referral page
│   ├── admin.html           ← Admin panel
│   ├── 404.html             ← Custom 404 page
│   ├── _headers             ← Cloudflare Pages security headers
│   ├── _redirects           ← URL redirects
│   ├── _routes.json         ← API routing to Worker
│   ├── config/
│   │   └── config.js        ← Public frontend config (no secrets)
│   ├── styles/
│   │   ├── style.css        ← User panel styles
│   │   └── admin.css        ← Admin panel styles
│   └── scripts/
│       ├── app.js           ← User panel JavaScript
│       └── admin.js         ← Admin panel JavaScript
│
├── workers/
│   └── worker.js            ← Cloudflare Worker (all API routes)
│
├── database/
│   └── schema.sql           ← D1 database schema + seed data
│
├── config/
│   └── config.js            ← Shared config reference
│
├── wrangler.toml            ← Cloudflare deployment config
├── package.json             ← NPM scripts
├── .gitignore
└── README.md
```

---

## ⚡ Quick Start — Deployment

### Prerequisites
- [Node.js](https://nodejs.org) v18+
- [Cloudflare account](https://dash.cloudflare.com) (free tier works)
- [Wrangler CLI](https://developers.cloudflare.com/workers/wrangler/)
- A Telegram Bot (create via [@BotFather](https://t.me/BotFather))

---

### Step 1 — Install Wrangler

```bash
npm install -g wrangler
wrangler login
```

---

### Step 2 — Create D1 Database

```bash
wrangler d1 create smm-panel-db
```

Copy the `database_id` from the output and paste it into `wrangler.toml`:

```toml
[[d1_databases]]
binding      = "DB"
database_name = "smm-panel-db"
database_id  = "PASTE_YOUR_DATABASE_ID_HERE"
```

---

### Step 3 — Create KV Namespace (rate limiting cache)

```bash
wrangler kv namespace create CACHE
```

Copy the `id` and `preview_id` values into `wrangler.toml`:

```toml
[[kv_namespaces]]
binding    = "CACHE"
id         = "PASTE_YOUR_KV_ID_HERE"
preview_id = "PASTE_YOUR_KV_PREVIEW_ID_HERE"
```

---

### Step 4 — Apply Database Schema

```bash
# Production
wrangler d1 execute smm-panel-db --file=./database/schema.sql

# Local dev
wrangler d1 execute smm-panel-db --local --file=./database/schema.sql
```

---

### Step 5 — Set Secrets

> ⚠️ Never put secrets in `wrangler.toml` or any committed file.

```bash
# Telegram Bot Token (from BotFather)
wrangler secret put BOT_TOKEN

# Admin panel secret key (choose a strong random string)
wrangler secret put ADMIN_SECRET_KEY

# JWT signing secret (choose a strong random string)
wrangler secret put JWT_SECRET
```

---

### Step 6 — Update Frontend Config

Edit `public/config/config.js`:

```js
const SMM_CONFIG = {
  PANEL_NAME:   'Your Panel Name',
  BOT_USERNAME: 'YourBotUsername',   // without @
  API_BASE:     '',                  // leave empty if same domain
};
```

---

### Step 7 — Deploy

```bash
# Deploy Worker + static assets
wrangler deploy

# Or deploy only the Worker
wrangler deploy --no-bundle
```

---

### Step 8 — Configure Telegram Bot

Set your Telegram Bot's WebApp URL via [@BotFather](https://t.me/BotFather):

```
/newapp → Set URL: https://smm-panel.yourname.workers.dev/index.html
```

Or add a menu button:
```
/setmenubutton → URL: https://smm-panel.yourname.workers.dev/index.html
```

---

### Step 9 — First Admin Login

1. Open `https://your-worker-url/admin.html`
2. Enter your **Telegram numeric ID** (get it from [@userinfobot](https://t.me/userinfobot))
3. Enter the **ADMIN_SECRET_KEY** you set in Step 5
4. On first login with no existing admins, a superadmin account is auto-created

---

## 🔧 Local Development

```bash
# Install deps
npm install

# Run local dev server
npm run dev
# → Opens http://localhost:8787
```

For Telegram WebApp testing locally, use [ngrok](https://ngrok.com):

```bash
ngrok http 8787
# Use the HTTPS URL as your WebApp URL in BotFather
```

---

## 🔐 Security Architecture

| Layer | Implementation |
|---|---|
| Telegram Auth | HMAC-SHA256 initData verification per Telegram docs |
| Admin Auth | JWT (HS256) with 7-day expiry |
| Rate Limiting | Cloudflare KV — 10 orders/60s per user |
| SQL Injection | Parameterized queries (D1 `bind()`) |
| Secrets | Cloudflare Worker Secrets (encrypted at rest) |
| CORS | Configured headers on all API routes |
| Input Validation | Server-side validation on all endpoints |

---

## 📡 API Reference

### User APIs

| Method | Endpoint | Description |
|---|---|---|
| `POST` | `/api/login` | Authenticate via Telegram initData |
| `POST` | `/api/home-data` | Get all home page data |
| `POST` | `/api/create-order` | Place a new order |
| `GET`  | `/api/orders` | Get user's order history |
| `GET`  | `/api/services` | List services (with filters) |
| `GET`  | `/api/settings` | Get public settings |
| `POST` | `/api/check-join` | Check Telegram channel membership |
| `GET`  | `/api/profile` | Get profile + transactions |

### Admin APIs (JWT required)

| Method | Endpoint | Description |
|---|---|---|
| `POST` | `/api/admin/login` | Admin login → JWT |
| `GET`  | `/api/admin/dashboard` | Stats + recent orders |
| `GET/POST` | `/api/admin/users` | List / search users |
| `POST` | `/api/admin/users/balance` | Add/remove user balance |
| `POST` | `/api/admin/users/block` | Block/unblock user |
| `*`    | `/api/admin/services` | CRUD services |
| `*`    | `/api/admin/categories` | CRUD categories |
| `*`    | `/api/admin/orders` | List & update orders |
| `*`    | `/api/admin/banners` | CRUD banners |
| `*`    | `/api/admin/announcements` | CRUD announcements |
| `*`    | `/api/admin/force-channels` | CRUD force-join channels |
| `GET/POST` | `/api/admin/settings` | Read / write settings |

---

## 🗄️ Database Schema

11 tables: `users`, `admins`, `categories`, `services`, `orders`, `transactions`, `referrals`, `settings`, `announcements`, `banners`, `force_channels`

See [`database/schema.sql`](./database/schema.sql) for full schema + seed data.

---

## 🔄 Scheduled Jobs

The Worker runs a cron every 6 hours to sync order statuses from your SMM provider API. Configure your provider integration in `workers/worker.js` → `scheduled()` handler.

---

## 🌍 Environment Variables

| Variable | Set via | Description |
|---|---|---|
| `BOT_TOKEN` | `wrangler secret put` | Telegram Bot Token |
| `ADMIN_SECRET_KEY` | `wrangler secret put` | Admin panel login key |
| `JWT_SECRET` | `wrangler secret put` | JWT signing key |
| `ENVIRONMENT` | `wrangler.toml [vars]` | `production` / `development` |

---

## 🚀 GitHub → Cloudflare CI/CD

1. Push your code to GitHub
2. Go to [Cloudflare Workers & Pages](https://dash.cloudflare.com)
3. **Workers & Pages → Create → Pages → Connect to Git**
4. Select your repo
5. Set **Build output directory**: `public`
6. Add environment variables (secrets) in the Pages dashboard
7. Every push to `main` auto-deploys 🎉

---

## 📦 Tech Stack

| Layer | Technology |
|---|---|
| Frontend | Vanilla HTML5, CSS3, JavaScript (ES2022) |
| Telegram | Telegram WebApp JS SDK |
| Backend | Cloudflare Workers (V8 isolates) |
| Database | Cloudflare D1 (SQLite) |
| Cache | Cloudflare KV |
| Auth | HMAC-SHA256 + JWT (HS256) |
| CDN | Cloudflare Pages (global edge) |
| Icons | Font Awesome 6 |
| Fonts | Plus Jakarta Sans, JetBrains Mono |

---

## 📝 License

MIT License — free to use, modify, and deploy.

---

## 🤝 Support

For issues and questions, create a GitHub issue or contact the admin via the panel's support link.
