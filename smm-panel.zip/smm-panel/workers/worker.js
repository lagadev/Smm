/**
 * worker.js — Cloudflare Worker Backend
 * SMM Panel v1.0.0
 *
 * Architecture: Single-file modular router
 * Database:     Cloudflare D1 (SQLite)
 * Auth:         Telegram initData HMAC + Admin JWT
 *
 * Routes:
 *   POST /api/login
 *   POST /api/home-data
 *   POST /api/create-order
 *   GET  /api/orders
 *   GET  /api/services
 *   GET  /api/settings
 *   POST /api/check-join
 *   POST /api/deposit
 *   GET  /api/profile
 *   POST /api/admin/login
 *   GET  /api/admin/dashboard
 *   GET|POST|PUT|DELETE /api/admin/*
 *
 * Scheduled: orderStatusSync (every 6 h)
 */

// ─────────────────────────────────────────────────────────────
// UTILITY HELPERS
// ─────────────────────────────────────────────────────────────

/** Uniform JSON response */
const json = (data, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Admin-Key',
    },
  });

/** Error shorthand */
const err = (msg, status = 400) => json({ status: 'error', message: msg }, status);
const ok  = (data = {})         => json({ status: 'success', ...data });

/** Parse request body safely */
async function parseBody(req) {
  try {
    const ct = req.headers.get('Content-Type') || '';
    if (ct.includes('application/json')) return await req.json();
    return {};
  } catch { return {}; }
}

/** Current Unix timestamp */
const now = () => Math.floor(Date.now() / 1000);

/** Generate a short alphanumeric referral code */
function genCode(length = 8) {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  return Array.from({ length }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
}

/** Simple rate-limit via KV (returns true if request is allowed) */
async function rateLimit(kv, key, max, windowSec) {
  try {
    const raw  = await kv.get(key);
    const hits = raw ? parseInt(raw, 10) : 0;
    if (hits >= max) return false;
    await kv.put(key, String(hits + 1), { expirationTtl: windowSec });
    return true;
  } catch { return true; } // fail open on KV error
}

// ─────────────────────────────────────────────────────────────
// TELEGRAM initData VERIFICATION
// ─────────────────────────────────────────────────────────────

/**
 * Verify Telegram WebApp initData using HMAC-SHA-256.
 * Returns parsed user object or null on failure.
 */
async function verifyTelegramInitData(initData, botToken) {
  if (!initData || !botToken) return null;

  try {
    const params   = new URLSearchParams(initData);
    const hash     = params.get('hash');
    if (!hash) return null;

    params.delete('hash');

    // Build data-check-string (sorted keys joined by \n)
    const dataCheck = [...params.entries()]
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([k, v]) => `${k}=${v}`)
      .join('\n');

    // HMAC key = HMAC-SHA256("WebAppData", botToken)
    const encoder   = new TextEncoder();
    const keyMat    = await crypto.subtle.importKey(
      'raw', encoder.encode('WebAppData'), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']
    );
    const secretKey = await crypto.subtle.sign('HMAC', keyMat, encoder.encode(botToken));

    const checkKey  = await crypto.subtle.importKey(
      'raw', secretKey, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']
    );
    const sig       = await crypto.subtle.sign('HMAC', checkKey, encoder.encode(dataCheck));

    const sigHex    = [...new Uint8Array(sig)].map(b => b.toString(16).padStart(2, '0')).join('');

    // Check timestamp (max 1 hour old)
    const authDate = parseInt(params.get('auth_date') || '0', 10);
    if (now() - authDate > 3600) return null;

    if (sigHex !== hash) return null;

    const userRaw = params.get('user');
    return userRaw ? JSON.parse(userRaw) : null;
  } catch { return null; }
}

// ─────────────────────────────────────────────────────────────
// ADMIN JWT (simple)
// ─────────────────────────────────────────────────────────────

async function signAdminJWT(payload, secret) {
  const header  = btoa(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
  const body    = btoa(JSON.stringify({ ...payload, iat: now() }));
  const msg     = `${header}.${body}`;
  const encoder = new TextEncoder();
  const key     = await crypto.subtle.importKey(
    'raw', encoder.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']
  );
  const sig = await crypto.subtle.sign('HMAC', key, encoder.encode(msg));
  const sigB64 = btoa(String.fromCharCode(...new Uint8Array(sig)));
  return `${msg}.${sigB64}`;
}

async function verifyAdminJWT(token, secret) {
  try {
    const [header, body, sig] = token.split('.');
    const msg     = `${header}.${body}`;
    const encoder = new TextEncoder();
    const key     = await crypto.subtle.importKey(
      'raw', encoder.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['verify']
    );
    const sigBytes = Uint8Array.from(atob(sig), c => c.charCodeAt(0));
    const valid    = await crypto.subtle.verify('HMAC', key, sigBytes, encoder.encode(msg));
    if (!valid) return null;

    const payload = JSON.parse(atob(body));
    if (payload.exp && payload.exp < now()) return null;
    return payload;
  } catch { return null; }
}

/** Extract admin JWT from Authorization header */
async function getAdminFromRequest(req, env) {
  const auth = req.headers.get('Authorization') || '';
  if (!auth.startsWith('Bearer ')) return null;
  return verifyAdminJWT(auth.slice(7), env.JWT_SECRET || 'default-secret');
}

// ─────────────────────────────────────────────────────────────
// DB HELPERS
// ─────────────────────────────────────────────────────────────

/** Get a single setting value */
async function getSetting(db, key) {
  const row = await db.prepare('SELECT value FROM settings WHERE key = ?').bind(key).first();
  return row ? row.value : null;
}

/** Get multiple settings as object */
async function getSettings(db, keys) {
  const result = {};
  for (const key of keys) {
    result[key] = await getSetting(db, key);
  }
  return result;
}

/** Find or create user from Telegram data */
async function upsertUser(db, tgUser, referCode = '') {
  const tgId = String(tgUser.id);

  // Look up existing user
  let user = await db.prepare('SELECT * FROM users WHERE tg_id = ?').bind(tgId).first();

  if (!user) {
    // New user — generate unique referral code
    let refCode = genCode();
    const existing = await db.prepare('SELECT id FROM users WHERE referral_code = ?').bind(refCode).first();
    if (existing) refCode = genCode(10);

    // Resolve referrer
    let referrerId = null;
    if (referCode) {
      const ref = await db.prepare('SELECT id FROM users WHERE referral_code = ?').bind(referCode).first();
      referrerId = ref ? ref.id : null;
    }

    await db.prepare(`
      INSERT INTO users (tg_id, first_name, last_name, username, photo_url, referral_code, referred_by)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).bind(
      tgId,
      tgUser.first_name || '',
      tgUser.last_name  || '',
      tgUser.username   || '',
      tgUser.photo_url  || '',
      refCode,
      referCode || ''
    ).run();

    user = await db.prepare('SELECT * FROM users WHERE tg_id = ?').bind(tgId).first();

    // Credit referral bonus
    if (referrerId && user) {
      const bonusSetting = await getSetting(db, 'referral_bonus');
      const bonus        = parseFloat(bonusSetting || '0');
      if (bonus > 0) {
        const referrer = await db.prepare('SELECT * FROM users WHERE id = ?').bind(referrerId).first();
        if (referrer) {
          const newBalance = parseFloat(referrer.balance) + bonus;
          await db.prepare('UPDATE users SET balance = ?, updated_at = ? WHERE id = ?')
            .bind(newBalance, now(), referrerId).run();
          await db.prepare(`
            INSERT INTO transactions (user_id, type, amount, balance_before, balance_after, reference, note)
            VALUES (?, 'referral_bonus', ?, ?, ?, ?, ?)
          `).bind(referrerId, bonus, parseFloat(referrer.balance), newBalance,
            String(user.id), `Referral bonus for inviting user ${tgId}`).run();
          await db.prepare('INSERT INTO referrals (referrer_id, referred_id, bonus_amount) VALUES (?, ?, ?)')
            .bind(referrerId, user.id, bonus).run();
        }
      }
    }
  } else {
    // Update profile fields
    await db.prepare(`
      UPDATE users SET first_name=?, last_name=?, username=?, updated_at=?
      WHERE tg_id=?
    `).bind(
      tgUser.first_name || user.first_name,
      tgUser.last_name  || user.last_name,
      tgUser.username   || user.username,
      now(),
      tgId
    ).run();
    user = await db.prepare('SELECT * FROM users WHERE tg_id = ?').bind(tgId).first();
  }

  return user;
}

// ─────────────────────────────────────────────────────────────
// API HANDLERS
// ─────────────────────────────────────────────────────────────

/* ── POST /api/login ──────────────────────────────────────── */
async function handleLogin(req, env) {
  const body     = await parseBody(req);
  const initData = body.init_data || '';
  const refCode  = body.ref || '';

  const botToken = env.BOT_TOKEN || await getSetting(env.DB, 'bot_token');
  const tgUser   = await verifyTelegramInitData(initData, botToken);

  if (!tgUser) return err('Invalid Telegram session. Please reopen from Telegram bot.', 401);

  const user = await upsertUser(env.DB, tgUser, refCode);
  if (!user) return err('Failed to create user account.');

  if (user.status === 'blocked') {
    return json({
      status: 'blocked',
      message: user.blocked_msg || 'Your account has been blocked.',
      admin_contact: await getSetting(env.DB, 'admin_contact'),
    });
  }

  return ok({
    user: {
      id:            user.id,
      tg_id:         user.tg_id,
      name:          `${user.first_name} ${user.last_name}`.trim(),
      username:      user.username,
      photo_url:     user.photo_url,
      balance:       parseFloat(user.balance),
      referral_code: user.referral_code,
      total_orders:  user.total_orders,
      total_spent:   parseFloat(user.total_spent),
    },
  });
}

/* ── POST /api/home-data ──────────────────────────────────── */
async function handleHomeData(req, env) {
  const body     = await parseBody(req);
  const initData = body.init_data || '';

  const botToken = env.BOT_TOKEN || await getSetting(env.DB, 'bot_token');
  const tgUser   = await verifyTelegramInitData(initData, botToken);
  if (!tgUser) return err('Unauthorized', 401);

  const user = await env.DB.prepare('SELECT * FROM users WHERE tg_id = ?')
    .bind(String(tgUser.id)).first();
  if (!user) return err('User not found.');

  // Load all needed data in parallel
  const [cats, services, banners, announcements, forceChannels, settings] = await Promise.all([
    env.DB.prepare("SELECT * FROM categories WHERE status='active' ORDER BY sort_order,id").all(),
    env.DB.prepare("SELECT s.*,c.platform_key FROM services s JOIN categories c ON c.id=s.category_id WHERE s.status='active' ORDER BY s.sort_order,s.id").all(),
    env.DB.prepare("SELECT * FROM banners WHERE status='active' ORDER BY sort_order,id").all(),
    env.DB.prepare("SELECT * FROM announcements WHERE status='active' ORDER BY sort_order,id").all(),
    env.DB.prepare("SELECT * FROM force_channels WHERE status='active' ORDER BY sort_order,id").all(),
    getSettings(env.DB, ['running_text','admin_contact','referral_enabled','deposit_enabled','order_enabled','currency_symbol']),
  ]);

  const runningParts = (announcements.results || [])
    .map(a => a.title ? `${a.title}: ${a.content}` : a.content)
    .join(' ✦ ') || settings.running_text;

  return ok({
    user_balance:   parseFloat(user.balance),
    user_status:    user.status,
    blocked_message: user.blocked_msg,
    admin_contact_link: settings.admin_contact,
    running_text:   runningParts || settings.running_text,
    categories:     cats.results     || [],
    services:       services.results || [],
    sliders:        (banners.results || []).map(b => ({ url: b.image_url, link: b.link_url, title: b.title })),
    announcements:  announcements.results  || [],
    force_channels: forceChannels.results  || [],
    settings: {
      currency_symbol:  settings.currency_symbol || '৳',
      referral_enabled: settings.referral_enabled === '1',
      deposit_enabled:  settings.deposit_enabled  === '1',
      order_enabled:    settings.order_enabled    === '1',
    },
  });
}

/* ── POST /api/create-order ───────────────────────────────── */
async function handleCreateOrder(req, env) {
  const body     = await parseBody(req);
  const initData = body.init_data || '';

  // Rate limit: 10 orders / 60 s per Telegram user
  const ipKey = `order:${body.tg_id || 'unknown'}`;
  const allowed = await rateLimit(env.CACHE, ipKey, 10, 60);
  if (!allowed) return err('Too many requests. Please wait.', 429);

  const botToken = env.BOT_TOKEN || await getSetting(env.DB, 'bot_token');
  const tgUser   = await verifyTelegramInitData(initData, botToken);
  if (!tgUser) return err('Unauthorized', 401);

  const user = await env.DB.prepare('SELECT * FROM users WHERE tg_id = ?')
    .bind(String(tgUser.id)).first();
  if (!user)              return err('User not found.');
  if (user.status === 'blocked') return err('Your account is blocked.');

  const { service_id, link, quantity, custom_comments = '' } = body;

  if (!service_id) return err('service_id is required.');
  if (!link)        return err('Link is required.');
  if (!quantity || quantity < 1) return err('Invalid quantity.');

  const service = await env.DB.prepare('SELECT * FROM services WHERE id = ? AND status = ?')
    .bind(service_id, 'active').first();
  if (!service) return err('Service not found or unavailable.');

  const qty = parseInt(quantity, 10);
  if (qty < service.min_qty) return err(`Minimum quantity is ${service.min_qty}.`);
  if (qty > service.max_qty) return err(`Maximum quantity is ${service.max_qty}.`);

  if ((service.needs_custom_comments === 1 || service.service_type === 'custom_comments') && !custom_comments) {
    return err('Custom comments are required for this service.');
  }

  const charge = (qty * parseFloat(service.rate_per_1000)) / 1000;
  const balance = parseFloat(user.balance);

  if (charge > balance) {
    return err(`Insufficient balance. Required: ${charge.toFixed(4)}, Available: ${balance.toFixed(4)}.`);
  }

  const newBalance = balance - charge;

  // Deduct balance & insert order atomically
  await env.DB.prepare('UPDATE users SET balance=?, total_orders=total_orders+1, total_spent=total_spent+?, updated_at=? WHERE id=?')
    .bind(newBalance, charge, now(), user.id).run();

  const orderResult = await env.DB.prepare(`
    INSERT INTO orders (user_id, service_id, link, quantity, charge, custom_comments, status)
    VALUES (?, ?, ?, ?, ?, ?, 'pending')
  `).bind(user.id, service.id, link, qty, charge, custom_comments).run();

  await env.DB.prepare(`
    INSERT INTO transactions (user_id, type, amount, balance_before, balance_after, reference, note)
    VALUES (?, 'order_charge', ?, ?, ?, ?, ?)
  `).bind(user.id, charge, balance, newBalance, String(orderResult.meta.last_row_id), `Order #${orderResult.meta.last_row_id}`).run();

  return ok({
    order_id: orderResult.meta.last_row_id,
    charge:   charge,
    balance:  newBalance,
    message:  'Order placed successfully!',
  });
}

/* ── GET /api/orders ─────────────────────────────────────── */
async function handleGetOrders(req, env) {
  const url      = new URL(req.url);
  const initData = url.searchParams.get('init_data') || '';
  const page     = parseInt(url.searchParams.get('page') || '1', 10);
  const limit    = 20;
  const offset   = (page - 1) * limit;

  const botToken = env.BOT_TOKEN || await getSetting(env.DB, 'bot_token');
  const tgUser   = await verifyTelegramInitData(initData, botToken);
  if (!tgUser) return err('Unauthorized', 401);

  const user = await env.DB.prepare('SELECT id FROM users WHERE tg_id = ?')
    .bind(String(tgUser.id)).first();
  if (!user) return err('User not found.');

  const orders = await env.DB.prepare(`
    SELECT o.*, s.name as service_name, s.rate_per_1000, c.platform_key
    FROM orders o
    JOIN services s ON s.id = o.service_id
    JOIN categories c ON c.id = s.category_id
    WHERE o.user_id = ?
    ORDER BY o.created_at DESC
    LIMIT ? OFFSET ?
  `).bind(user.id, limit, offset).all();

  const total = await env.DB.prepare('SELECT COUNT(*) as cnt FROM orders WHERE user_id = ?')
    .bind(user.id).first();

  return ok({
    orders:  orders.results || [],
    total:   total?.cnt || 0,
    page,
    pages:   Math.ceil((total?.cnt || 0) / limit),
  });
}

/* ── GET /api/services ───────────────────────────────────── */
async function handleGetServices(req, env) {
  const url     = new URL(req.url);
  const catId   = url.searchParams.get('category_id');
  const platform = url.searchParams.get('platform');

  let query  = "SELECT s.*,c.platform_key,c.name as category_name FROM services s JOIN categories c ON c.id=s.category_id WHERE s.status='active'";
  const args = [];

  if (catId) { query += ' AND s.category_id=?'; args.push(catId); }
  if (platform && platform !== 'all') { query += " AND c.platform_key=?"; args.push(platform); }
  query += ' ORDER BY s.sort_order,s.id';

  const stmt   = env.DB.prepare(query);
  const result = args.length ? await stmt.bind(...args).all() : await stmt.all();

  return ok({ services: result.results || [] });
}

/* ── GET /api/settings ───────────────────────────────────── */
async function handleGetSettings(req, env) {
  const result = await env.DB.prepare("SELECT key,value FROM settings").all();
  const s = {};
  for (const row of (result.results || [])) {
    // Never expose bot_token or secrets
    if (['bot_token'].includes(row.key)) continue;
    s[row.key] = row.value;
  }
  return ok({ settings: s });
}

/* ── POST /api/check-join ────────────────────────────────── */
async function handleCheckJoin(req, env) {
  const body       = await parseBody(req);
  const initData   = body.init_data    || '';
  const forceCheck = body.force_refresh || false;

  const botToken = env.BOT_TOKEN || await getSetting(env.DB, 'bot_token');
  const tgUser   = await verifyTelegramInitData(initData, botToken);
  if (!tgUser) return err('Unauthorized', 401);

  const user = await env.DB.prepare('SELECT * FROM users WHERE tg_id = ?')
    .bind(String(tgUser.id)).first();
  if (!user) return err('User not found.');

  const DAILY = 86400;
  const lastCheck = user.last_join_check || 0;

  // Rate-limit: only re-check once per day unless force
  if (!forceCheck && (now() - lastCheck) < DAILY) {
    return ok({ all_joined: true, channels: [], cached: true });
  }

  const channels = await env.DB.prepare("SELECT * FROM force_channels WHERE status='active' ORDER BY sort_order")
    .all();
  const chList = channels.results || [];

  if (!chList.length) {
    return ok({ all_joined: true, channels: [] });
  }

  // Check membership via Telegram Bot API
  const token  = env.BOT_TOKEN || '';
  const joined = [];
  const notJoined = [];

  for (const ch of chList) {
    try {
      const apiUrl = `https://api.telegram.org/bot${token}/getChatMember?chat_id=${ch.channel_id}&user_id=${tgUser.id}`;
      const res    = await fetch(apiUrl);
      const data   = await res.json();
      const status = data?.result?.status;
      const isMember = ['member','administrator','creator'].includes(status);
      (isMember ? joined : notJoined).push({ ...ch, joined: isMember });
    } catch {
      notJoined.push({ ...ch, joined: false });
    }
  }

  const allJoined = notJoined.length === 0;

  // Update last check timestamp
  await env.DB.prepare('UPDATE users SET last_join_check=? WHERE id=?')
    .bind(now(), user.id).run();

  return ok({
    all_joined: allJoined,
    channels:   allJoined ? [] : notJoined,
  });
}

/* ── GET /api/profile ────────────────────────────────────── */
async function handleGetProfile(req, env) {
  const url      = new URL(req.url);
  const initData = url.searchParams.get('init_data') || '';

  const botToken = env.BOT_TOKEN || await getSetting(env.DB, 'bot_token');
  const tgUser   = await verifyTelegramInitData(initData, botToken);
  if (!tgUser) return err('Unauthorized', 401);

  const user = await env.DB.prepare('SELECT * FROM users WHERE tg_id = ?')
    .bind(String(tgUser.id)).first();
  if (!user) return err('User not found.');

  const referrals = await env.DB.prepare(
    'SELECT COUNT(*) as cnt, SUM(bonus_amount) as total FROM referrals WHERE referrer_id = ?'
  ).bind(user.id).first();

  const txns = await env.DB.prepare(
    'SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 10'
  ).bind(user.id).all();

  return ok({
    user: {
      id:            user.id,
      tg_id:         user.tg_id,
      name:          `${user.first_name} ${user.last_name}`.trim(),
      username:      user.username,
      photo_url:     user.photo_url,
      balance:       parseFloat(user.balance),
      total_spent:   parseFloat(user.total_spent),
      total_orders:  user.total_orders,
      referral_code: user.referral_code,
      created_at:    user.created_at,
    },
    referral_stats: {
      count: referrals?.cnt || 0,
      earned: parseFloat(referrals?.total || 0),
    },
    recent_transactions: txns.results || [],
  });
}

// ─────────────────────────────────────────────────────────────
// ADMIN API HANDLERS
// ─────────────────────────────────────────────────────────────

/* ── POST /api/admin/login ───────────────────────────────── */
async function handleAdminLogin(req, env) {
  const body    = await parseBody(req);
  const tgId    = String(body.tg_id || '');
  const secret  = body.secret || '';

  if (!tgId || !secret) return err('tg_id and secret are required.');

  // Validate admin secret key
  if (secret !== (env.ADMIN_SECRET_KEY || 'change-me-secret')) {
    return err('Invalid credentials.', 401);
  }

  // Check admin record
  let admin = await env.DB.prepare('SELECT * FROM admins WHERE tg_id = ? AND status = ?')
    .bind(tgId, 'active').first();

  if (!admin) {
    // Auto-create superadmin on first login if none exist
    const count = await env.DB.prepare('SELECT COUNT(*) as c FROM admins').first();
    if (count?.c === 0) {
      await env.DB.prepare("INSERT INTO admins (tg_id, username, name, role) VALUES (?, ?, ?, 'superadmin')")
        .bind(tgId, body.username || '', body.name || 'Admin').run();
      admin = await env.DB.prepare('SELECT * FROM admins WHERE tg_id = ?').bind(tgId).first();
    } else {
      return err('Admin account not found or inactive.', 401);
    }
  }

  const token = await signAdminJWT(
    { tg_id: tgId, admin_id: admin.id, role: admin.role, exp: now() + 86400 * 7 },
    env.JWT_SECRET || 'default-secret'
  );

  return ok({ token, admin: { id: admin.id, tg_id: admin.tg_id, name: admin.name, role: admin.role } });
}

/* ── GET /api/admin/dashboard ────────────────────────────── */
async function handleAdminDashboard(req, env) {
  const admin = await getAdminFromRequest(req, env);
  if (!admin) return err('Unauthorized', 401);

  const [users, orders, revenue, pendingOrders, services, todayOrders] = await Promise.all([
    env.DB.prepare('SELECT COUNT(*) as cnt FROM users').first(),
    env.DB.prepare('SELECT COUNT(*) as cnt FROM orders').first(),
    env.DB.prepare("SELECT SUM(charge) as total FROM orders WHERE status != 'cancelled'").first(),
    env.DB.prepare("SELECT COUNT(*) as cnt FROM orders WHERE status='pending'").first(),
    env.DB.prepare('SELECT COUNT(*) as cnt FROM services').first(),
    env.DB.prepare("SELECT COUNT(*) as cnt FROM orders WHERE created_at >= strftime('%s','now','-1 day')").first(),
  ]);

  const recentOrders = await env.DB.prepare(`
    SELECT o.*, u.first_name, u.username, s.name as service_name
    FROM orders o JOIN users u ON u.id=o.user_id JOIN services s ON s.id=o.service_id
    ORDER BY o.created_at DESC LIMIT 10
  `).all();

  return ok({
    stats: {
      total_users:    users?.cnt         || 0,
      total_orders:   orders?.cnt        || 0,
      total_revenue:  parseFloat(revenue?.total || 0),
      pending_orders: pendingOrders?.cnt || 0,
      total_services: services?.cnt      || 0,
      today_orders:   todayOrders?.cnt   || 0,
    },
    recent_orders: recentOrders.results || [],
  });
}

/* ── GET /api/admin/users ────────────────────────────────── */
async function handleAdminUsers(req, env) {
  const admin = await getAdminFromRequest(req, env);
  if (!admin) return err('Unauthorized', 401);

  const url    = new URL(req.url);
  const page   = parseInt(url.searchParams.get('page') || '1', 10);
  const search = url.searchParams.get('search') || '';
  const limit  = 20;
  const offset = (page - 1) * limit;

  let query  = 'SELECT * FROM users';
  const args = [];

  if (search) {
    query += ' WHERE tg_id LIKE ? OR first_name LIKE ? OR username LIKE ?';
    const s = `%${search}%`;
    args.push(s, s, s);
  }
  query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
  args.push(limit, offset);

  const users = await env.DB.prepare(query).bind(...args).all();
  const total = await env.DB.prepare(
    search
      ? 'SELECT COUNT(*) as cnt FROM users WHERE tg_id LIKE ? OR first_name LIKE ? OR username LIKE ?'
      : 'SELECT COUNT(*) as cnt FROM users'
  ).bind(...(search ? [`%${search}%`, `%${search}%`, `%${search}%`] : [])).first();

  return ok({ users: users.results || [], total: total?.cnt || 0, page, pages: Math.ceil((total?.cnt || 0) / limit) });
}

/* ── POST /api/admin/users/balance ──────────────────────── */
async function handleAdminUserBalance(req, env) {
  const admin = await getAdminFromRequest(req, env);
  if (!admin) return err('Unauthorized', 401);

  const body   = await parseBody(req);
  const userId = parseInt(body.user_id, 10);
  const amount = parseFloat(body.amount || 0);
  const type   = body.type || 'add'; // 'add' | 'remove'
  const note   = body.note || '';

  if (!userId || isNaN(amount)) return err('user_id and amount are required.');

  const user = await env.DB.prepare('SELECT * FROM users WHERE id = ?').bind(userId).first();
  if (!user) return err('User not found.');

  const before   = parseFloat(user.balance);
  const newBal   = type === 'add' ? before + amount : Math.max(0, before - amount);
  const txType   = type === 'add' ? 'admin_add' : 'admin_remove';

  await env.DB.prepare('UPDATE users SET balance=?, updated_at=? WHERE id=?')
    .bind(newBal, now(), userId).run();

  await env.DB.prepare(`
    INSERT INTO transactions (user_id, type, amount, balance_before, balance_after, reference, note)
    VALUES (?, ?, ?, ?, ?, 'admin', ?)
  `).bind(userId, txType, amount, before, newBal, note || `Admin ${type} balance`).run();

  return ok({ new_balance: newBal, message: 'Balance updated.' });
}

/* ── POST /api/admin/users/block ─────────────────────────── */
async function handleAdminUserBlock(req, env) {
  const admin = await getAdminFromRequest(req, env);
  if (!admin) return err('Unauthorized', 401);

  const body   = await parseBody(req);
  const userId = parseInt(body.user_id, 10);
  const action = body.action || 'block'; // 'block' | 'unblock'
  const msg    = body.message || '';

  if (!userId) return err('user_id required.');

  const status = action === 'block' ? 'blocked' : 'active';
  await env.DB.prepare('UPDATE users SET status=?, blocked_msg=?, updated_at=? WHERE id=?')
    .bind(status, action === 'block' ? msg : '', now(), userId).run();

  return ok({ message: `User ${action}ed.` });
}

/* ── CRUD /api/admin/services ────────────────────────────── */
async function handleAdminServices(req, env) {
  const admin = await getAdminFromRequest(req, env);
  if (!admin) return err('Unauthorized', 401);

  const method = req.method;
  const url    = new URL(req.url);

  if (method === 'GET') {
    const page   = parseInt(url.searchParams.get('page') || '1', 10);
    const limit  = 30;
    const offset = (page - 1) * limit;
    const result = await env.DB.prepare(`
      SELECT s.*, c.name as category_name, c.platform_key
      FROM services s JOIN categories c ON c.id=s.category_id
      ORDER BY s.sort_order, s.id LIMIT ? OFFSET ?
    `).bind(limit, offset).all();
    const total = await env.DB.prepare('SELECT COUNT(*) as cnt FROM services').first();
    return ok({ services: result.results || [], total: total?.cnt || 0 });
  }

  const body = await parseBody(req);

  if (method === 'POST') {
    const r = await env.DB.prepare(`
      INSERT INTO services (category_id, name, description, rate_per_1000, min_qty, max_qty,
        service_type, needs_custom_comments, visible_service_id, avg_time, sort_order, status)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
    `).bind(
      body.category_id, body.name, body.description || '',
      body.rate_per_1000, body.min_qty, body.max_qty,
      body.service_type || 'default',
      body.needs_custom_comments ? 1 : 0,
      body.visible_service_id || '',
      body.avg_time || '', body.sort_order || 0,
      body.status || 'active'
    ).run();
    return ok({ id: r.meta.last_row_id, message: 'Service created.' });
  }

  if (method === 'PUT') {
    const id = parseInt(url.searchParams.get('id'), 10);
    if (!id) return err('id required.');
    await env.DB.prepare(`
      UPDATE services SET category_id=?, name=?, description=?, rate_per_1000=?,
        min_qty=?, max_qty=?, service_type=?, needs_custom_comments=?,
        visible_service_id=?, avg_time=?, sort_order=?, status=?
      WHERE id=?
    `).bind(
      body.category_id, body.name, body.description || '',
      body.rate_per_1000, body.min_qty, body.max_qty,
      body.service_type || 'default',
      body.needs_custom_comments ? 1 : 0,
      body.visible_service_id || '',
      body.avg_time || '', body.sort_order || 0,
      body.status || 'active', id
    ).run();
    return ok({ message: 'Service updated.' });
  }

  if (method === 'DELETE') {
    const id = parseInt(url.searchParams.get('id'), 10);
    if (!id) return err('id required.');
    await env.DB.prepare('UPDATE services SET status=? WHERE id=?').bind('hidden', id).run();
    return ok({ message: 'Service hidden.' });
  }

  return err('Method not allowed.', 405);
}

/* ── CRUD /api/admin/categories ─────────────────────────── */
async function handleAdminCategories(req, env) {
  const admin = await getAdminFromRequest(req, env);
  if (!admin) return err('Unauthorized', 401);

  const method = req.method;
  const url    = new URL(req.url);

  if (method === 'GET') {
    const result = await env.DB.prepare('SELECT * FROM categories ORDER BY sort_order, id').all();
    return ok({ categories: result.results || [] });
  }

  const body = await parseBody(req);

  if (method === 'POST') {
    const r = await env.DB.prepare(
      'INSERT INTO categories (name, platform_key, sort_order, status) VALUES (?,?,?,?)'
    ).bind(body.name, body.platform_key || 'all', body.sort_order || 0, body.status || 'active').run();
    return ok({ id: r.meta.last_row_id, message: 'Category created.' });
  }

  if (method === 'PUT') {
    const id = parseInt(url.searchParams.get('id'), 10);
    if (!id) return err('id required.');
    await env.DB.prepare('UPDATE categories SET name=?, platform_key=?, sort_order=?, status=? WHERE id=?')
      .bind(body.name, body.platform_key || 'all', body.sort_order || 0, body.status || 'active', id).run();
    return ok({ message: 'Category updated.' });
  }

  if (method === 'DELETE') {
    const id = parseInt(url.searchParams.get('id'), 10);
    if (!id) return err('id required.');
    await env.DB.prepare('DELETE FROM categories WHERE id=?').bind(id).run();
    return ok({ message: 'Category deleted.' });
  }

  return err('Method not allowed.', 405);
}

/* ── CRUD /api/admin/orders ──────────────────────────────── */
async function handleAdminOrders(req, env) {
  const admin = await getAdminFromRequest(req, env);
  if (!admin) return err('Unauthorized', 401);

  const url    = new URL(req.url);
  const method = req.method;

  if (method === 'GET') {
    const page   = parseInt(url.searchParams.get('page') || '1', 10);
    const status = url.searchParams.get('status') || '';
    const limit  = 20;
    const offset = (page - 1) * limit;
    let   query  = `SELECT o.*, u.first_name, u.username, s.name as service_name
                    FROM orders o JOIN users u ON u.id=o.user_id JOIN services s ON s.id=o.service_id`;
    const args   = [];
    if (status) { query += ' WHERE o.status=?'; args.push(status); }
    query += ' ORDER BY o.created_at DESC LIMIT ? OFFSET ?';
    args.push(limit, offset);
    const result = await env.DB.prepare(query).bind(...args).all();
    const total  = await env.DB.prepare(
      status ? 'SELECT COUNT(*) as cnt FROM orders WHERE status=?' : 'SELECT COUNT(*) as cnt FROM orders'
    ).bind(...(status ? [status] : [])).first();
    return ok({ orders: result.results || [], total: total?.cnt || 0 });
  }

  if (method === 'PUT') {
    const body    = await parseBody(req);
    const orderId = parseInt(url.searchParams.get('id'), 10);
    if (!orderId) return err('id required.');
    await env.DB.prepare('UPDATE orders SET status=?, note=?, updated_at=? WHERE id=?')
      .bind(body.status, body.note || '', now(), orderId).run();

    // If refunded, credit back to user
    if (body.status === 'refunded') {
      const order = await env.DB.prepare('SELECT * FROM orders WHERE id=?').bind(orderId).first();
      if (order) {
        const user = await env.DB.prepare('SELECT * FROM users WHERE id=?').bind(order.user_id).first();
        if (user) {
          const newBal = parseFloat(user.balance) + parseFloat(order.charge);
          await env.DB.prepare('UPDATE users SET balance=? WHERE id=?').bind(newBal, user.id).run();
          await env.DB.prepare(`
            INSERT INTO transactions (user_id, type, amount, balance_before, balance_after, reference, note)
            VALUES (?, 'refund', ?, ?, ?, ?, ?)
          `).bind(user.id, order.charge, parseFloat(user.balance), newBal,
            String(orderId), `Refund for order #${orderId}`).run();
        }
      }
    }
    return ok({ message: 'Order updated.' });
  }

  return err('Method not allowed.', 405);
}

/* ── CRUD /api/admin/banners ─────────────────────────────── */
async function handleAdminBanners(req, env) {
  const admin = await getAdminFromRequest(req, env);
  if (!admin) return err('Unauthorized', 401);

  const method = req.method;
  const url    = new URL(req.url);

  if (method === 'GET') {
    const r = await env.DB.prepare('SELECT * FROM banners ORDER BY sort_order,id').all();
    return ok({ banners: r.results || [] });
  }

  const body = await parseBody(req);

  if (method === 'POST') {
    const r = await env.DB.prepare(
      'INSERT INTO banners (title, image_url, link_url, sort_order, status) VALUES (?,?,?,?,?)'
    ).bind(body.title || '', body.image_url, body.link_url || '', body.sort_order || 0, body.status || 'active').run();
    return ok({ id: r.meta.last_row_id, message: 'Banner created.' });
  }

  if (method === 'PUT') {
    const id = parseInt(url.searchParams.get('id'), 10);
    if (!id) return err('id required.');
    await env.DB.prepare('UPDATE banners SET title=?, image_url=?, link_url=?, sort_order=?, status=? WHERE id=?')
      .bind(body.title || '', body.image_url, body.link_url || '', body.sort_order || 0, body.status || 'active', id).run();
    return ok({ message: 'Banner updated.' });
  }

  if (method === 'DELETE') {
    const id = parseInt(url.searchParams.get('id'), 10);
    if (!id) return err('id required.');
    await env.DB.prepare('DELETE FROM banners WHERE id=?').bind(id).run();
    return ok({ message: 'Banner deleted.' });
  }

  return err('Method not allowed.', 405);
}

/* ── CRUD /api/admin/announcements ──────────────────────── */
async function handleAdminAnnouncements(req, env) {
  const admin = await getAdminFromRequest(req, env);
  if (!admin) return err('Unauthorized', 401);

  const method = req.method;
  const url    = new URL(req.url);

  if (method === 'GET') {
    const r = await env.DB.prepare('SELECT * FROM announcements ORDER BY sort_order,id').all();
    return ok({ announcements: r.results || [] });
  }

  const body = await parseBody(req);

  if (method === 'POST') {
    const r = await env.DB.prepare(
      'INSERT INTO announcements (title, content, type, sort_order, status) VALUES (?,?,?,?,?)'
    ).bind(body.title, body.content, body.type || 'info', body.sort_order || 0, body.status || 'active').run();
    return ok({ id: r.meta.last_row_id, message: 'Announcement created.' });
  }

  if (method === 'PUT') {
    const id = parseInt(url.searchParams.get('id'), 10);
    if (!id) return err('id required.');
    await env.DB.prepare('UPDATE announcements SET title=?, content=?, type=?, sort_order=?, status=? WHERE id=?')
      .bind(body.title, body.content, body.type || 'info', body.sort_order || 0, body.status || 'active', id).run();
    return ok({ message: 'Announcement updated.' });
  }

  if (method === 'DELETE') {
    const id = parseInt(url.searchParams.get('id'), 10);
    if (!id) return err('id required.');
    await env.DB.prepare('DELETE FROM announcements WHERE id=?').bind(id).run();
    return ok({ message: 'Announcement deleted.' });
  }

  return err('Method not allowed.', 405);
}

/* ── CRUD /api/admin/force-channels ─────────────────────── */
async function handleAdminForceChannels(req, env) {
  const admin = await getAdminFromRequest(req, env);
  if (!admin) return err('Unauthorized', 401);

  const method = req.method;
  const url    = new URL(req.url);

  if (method === 'GET') {
    const r = await env.DB.prepare('SELECT * FROM force_channels ORDER BY sort_order,id').all();
    return ok({ channels: r.results || [] });
  }

  const body = await parseBody(req);

  if (method === 'POST') {
    const r = await env.DB.prepare(
      'INSERT INTO force_channels (title, channel_username, channel_id, invite_link, sort_order, status) VALUES (?,?,?,?,?,?)'
    ).bind(body.title, body.channel_username, body.channel_id, body.invite_link || '',
      body.sort_order || 0, body.status || 'active').run();
    return ok({ id: r.meta.last_row_id, message: 'Channel added.' });
  }

  if (method === 'PUT') {
    const id = parseInt(url.searchParams.get('id'), 10);
    if (!id) return err('id required.');
    await env.DB.prepare(
      'UPDATE force_channels SET title=?, channel_username=?, channel_id=?, invite_link=?, sort_order=?, status=? WHERE id=?'
    ).bind(body.title, body.channel_username, body.channel_id, body.invite_link || '',
      body.sort_order || 0, body.status || 'active', id).run();
    return ok({ message: 'Channel updated.' });
  }

  if (method === 'DELETE') {
    const id = parseInt(url.searchParams.get('id'), 10);
    if (!id) return err('id required.');
    await env.DB.prepare('DELETE FROM force_channels WHERE id=?').bind(id).run();
    return ok({ message: 'Channel deleted.' });
  }

  return err('Method not allowed.', 405);
}

/* ── GET|POST /api/admin/settings ───────────────────────── */
async function handleAdminSettings(req, env) {
  const admin = await getAdminFromRequest(req, env);
  if (!admin) return err('Unauthorized', 401);

  if (req.method === 'GET') {
    const r = await env.DB.prepare('SELECT key, value FROM settings').all();
    const s = {};
    for (const row of (r.results || [])) s[row.key] = row.value;
    return ok({ settings: s });
  }

  if (req.method === 'POST') {
    const body = await parseBody(req);
    for (const [key, value] of Object.entries(body)) {
      await env.DB.prepare(
        "INSERT INTO settings (key, value, updated_at) VALUES (?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at"
      ).bind(key, String(value), now()).run();
    }
    return ok({ message: 'Settings saved.' });
  }

  return err('Method not allowed.', 405);
}

// ─────────────────────────────────────────────────────────────
// ROUTER
// ─────────────────────────────────────────────────────────────

const ROUTES = [
  { method: 'POST', path: '/api/login',                    handler: handleLogin },
  { method: 'POST', path: '/api/home-data',                handler: handleHomeData },
  { method: 'POST', path: '/api/create-order',             handler: handleCreateOrder },
  { method: 'GET',  path: '/api/orders',                   handler: handleGetOrders },
  { method: 'GET',  path: '/api/services',                 handler: handleGetServices },
  { method: 'GET',  path: '/api/settings',                 handler: handleGetSettings },
  { method: 'POST', path: '/api/check-join',               handler: handleCheckJoin },
  { method: 'GET',  path: '/api/profile',                  handler: handleGetProfile },
  { method: 'POST', path: '/api/admin/login',              handler: handleAdminLogin },
  { method: 'GET',  path: '/api/admin/dashboard',          handler: handleAdminDashboard },
  { method: '*',    path: '/api/admin/users/balance',      handler: handleAdminUserBalance },
  { method: '*',    path: '/api/admin/users/block',        handler: handleAdminUserBlock },
  { method: '*',    path: '/api/admin/users',              handler: handleAdminUsers },
  { method: '*',    path: '/api/admin/services',           handler: handleAdminServices },
  { method: '*',    path: '/api/admin/categories',         handler: handleAdminCategories },
  { method: '*',    path: '/api/admin/orders',             handler: handleAdminOrders },
  { method: '*',    path: '/api/admin/banners',            handler: handleAdminBanners },
  { method: '*',    path: '/api/admin/announcements',      handler: handleAdminAnnouncements },
  { method: '*',    path: '/api/admin/force-channels',     handler: handleAdminForceChannels },
  { method: '*',    path: '/api/admin/settings',           handler: handleAdminSettings },
];

function matchRoute(method, pathname) {
  return ROUTES.find(r =>
    (r.method === '*' || r.method === method) && pathname === r.path
  );
}

// ─────────────────────────────────────────────────────────────
// MAIN FETCH HANDLER
// ─────────────────────────────────────────────────────────────

export default {
  async fetch(request, env, ctx) {
    const url    = new URL(request.url);
    const path   = url.pathname;
    const method = request.method;

    // CORS pre-flight
    if (method === 'OPTIONS') {
      return new Response(null, {
        status: 204,
        headers: {
          'Access-Control-Allow-Origin':  '*',
          'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
          'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Admin-Key',
          'Access-Control-Max-Age':       '86400',
        },
      });
    }

    // API routing
    if (path.startsWith('/api/')) {
      const route = matchRoute(method, path);
      if (route) {
        try {
          return await route.handler(request, env, ctx);
        } catch (e) {
          console.error('[Worker Error]', e);
          return err('Internal server error.', 500);
        }
      }
      return err('API route not found.', 404);
    }

    // Static assets via ASSETS binding (Cloudflare Pages)
    if (env.ASSETS) {
      return env.ASSETS.fetch(request);
    }

    return new Response('Not found', { status: 404 });
  },

  // ── Scheduled Task: sync order statuses ──────────────────
  async scheduled(event, env, ctx) {
    console.log('[Scheduled] Running order status sync…');
    try {
      const pending = await env.DB.prepare(
        "SELECT o.*, s.provider_service_id FROM orders o JOIN services s ON s.id=o.service_id WHERE o.status='processing' AND o.provider_order_id != '' LIMIT 50"
      ).all();

      // TODO: integrate with your SMM provider API here
      // For each order, call provider API and update status
      console.log(`[Scheduled] Found ${pending.results?.length || 0} processing orders.`);
    } catch (e) {
      console.error('[Scheduled Error]', e);
    }
  },
};
