/**
 * config.js — Shared frontend configuration
 * SMM Panel v1.0.0
 *
 * Edit ONLY the values below — never put secrets here.
 */

const SMM_CONFIG = {
  // Panel identity
  PANEL_NAME:       'SMM Panel',
  CURRENCY_SYMBOL:  '৳',
  VERSION:          '1.0.0',

  // API base URL.
  // • If serving everything from the same Worker domain → keep ''
  // • If using Cloudflare Pages + separate Worker →
  //     'https://smm-panel.yourname.workers.dev'
  API_BASE: '',

  // Telegram bot username (without @). Used for referral links.
  BOT_USERNAME: 'YourBotUsername',

  // Feature flags (can be overridden by /api/settings at runtime)
  FEATURES: {
    referral: true,
    deposit:  true,
    ordering: true,
  },

  // UI
  SLIDER_INTERVAL: 4000,   // ms between banner slides
  TIMEOUT:         15000,  // fetch timeout in ms
};

// Expose globally
window.SMM_CONFIG = SMM_CONFIG;
