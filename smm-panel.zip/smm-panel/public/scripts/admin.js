/**
 * admin.js — Admin Panel Frontend Logic
 * SMM Panel v1.0.0
 *
 * Pages: Dashboard, Users, Orders, Categories, Services,
 *        Banners, Announcements, Force Channels, Settings
 */

'use strict';

// ─────────────────────────────────────────────────────────────
// STATE & CONFIG
// ─────────────────────────────────────────────────────────────
const ADMIN = {
  token:   localStorage.getItem('smm_admin_token') || '',
  profile: JSON.parse(localStorage.getItem('smm_admin_info') || '{}'),
  page:    'dashboard',
};

const API_BASE = (window.SMM_CONFIG?.API_BASE || '').replace(/\/$/, '');

// ─────────────────────────────────────────────────────────────
// API HELPER
// ─────────────────────────────────────────────────────────────
async function api(path, opts = {}) {
  const url     = `${API_BASE}${path}`;
  const method  = opts.method || 'GET';
  const headers = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${ADMIN.token}`,
    ...(opts.headers || {}),
  };
  try {
    const res  = await fetch(url, {
      method,
      headers,
      body: opts.body ? JSON.stringify(opts.body) : undefined,
    });
    return await res.json();
  } catch (e) {
    return { status: 'error', message: 'Network error.' };
  }
}

// ─────────────────────────────────────────────────────────────
// TOAST
// ─────────────────────────────────────────────────────────────
function toast(msg, type = 'success') {
  const icons = { success: 'fa-check-circle', danger: 'fa-times-circle', warning: 'fa-exclamation-circle', info: 'fa-info-circle' };
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = `<i class="fas ${icons[type] || icons.info}" style="color:var(--${type === 'success' ? 'success' : type === 'danger' ? 'danger' : type === 'warning' ? 'warning' : 'info'})"></i> ${escHtml(msg)}`;
  document.getElementById('toastContainer').appendChild(el);
  setTimeout(() => el.remove(), 3500);
}

// ─────────────────────────────────────────────────────────────
// MODAL
// ─────────────────────────────────────────────────────────────
const modalEl     = document.getElementById('modal');
const modalTitleEl = document.getElementById('modalTitle');
const modalBodyEl  = document.getElementById('modalBody');
const modalSaveEl  = document.getElementById('modalSave');
const modalCancelEl= document.getElementById('modalCancel');
const modalCloseEl = document.getElementById('modalClose');

function openModal(title, bodyHtml, onSave, saveLabel = 'Save') {
  modalTitleEl.textContent = title;
  modalBodyEl.innerHTML    = bodyHtml;
  modalSaveEl.textContent  = saveLabel;
  modalSaveEl.onclick = async () => { await onSave(); };
  modalEl.classList.add('show');
}

function closeModal() { modalEl.classList.remove('show'); }

modalCloseEl.onclick  = closeModal;
modalCancelEl.onclick = closeModal;
modalEl.addEventListener('click', e => { if (e.target === modalEl) closeModal(); });

// ─────────────────────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────────────────────
function escHtml(t) { const d = document.createElement('div'); d.textContent = t ?? ''; return d.innerHTML; }
function fmtMoney(n) { return '৳' + Number(n || 0).toFixed(4); }
function fmtDate(ts) { if (!ts) return '—'; return new Date(ts * 1000).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }); }
function fmtNum(n)   { return Number(n || 0).toLocaleString(); }

const STATUS_BADGE = {
  pending:    '<span class="badge badge-pending">Pending</span>',
  processing: '<span class="badge badge-processing">Processing</span>',
  completed:  '<span class="badge badge-completed">Completed</span>',
  partial:    '<span class="badge badge-partial">Partial</span>',
  cancelled:  '<span class="badge badge-cancelled">Cancelled</span>',
  refunded:   '<span class="badge badge-refunded">Refunded</span>',
  active:     '<span class="badge badge-completed">Active</span>',
  blocked:    '<span class="badge badge-cancelled">Blocked</span>',
  hidden:     '<span class="badge badge-cancelled">Hidden</span>',
};

function badge(status) { return STATUS_BADGE[status] || `<span class="badge">${escHtml(status)}</span>`; }

function pagination(page, pages, onGo) {
  if (pages <= 1) return '';
  const prev = page > 1     ? `<button class="page-btn" data-p="${page-1}"><i class="fas fa-chevron-left"></i></button>` : '<button class="page-btn" disabled><i class="fas fa-chevron-left"></i></button>';
  const next = page < pages ? `<button class="page-btn" data-p="${page+1}"><i class="fas fa-chevron-right"></i></button>` : '<button class="page-btn" disabled><i class="fas fa-chevron-right"></i></button>';
  const nums = Array.from({ length: Math.min(pages, 7) }, (_, i) => {
    const p = i + 1;
    return `<button class="page-btn ${p === page ? 'active' : ''}" data-p="${p}">${p}</button>`;
  }).join('');
  return `<div class="pagination">${prev}${nums}${next}</div>`;
}

function bindPagination(container, onGo) {
  container.querySelectorAll('.page-btn[data-p]').forEach(btn => {
    btn.addEventListener('click', () => onGo(parseInt(btn.dataset.p)));
  });
}

// ─────────────────────────────────────────────────────────────
// NAVIGATION
// ─────────────────────────────────────────────────────────────
const PAGE_TITLES = {
  dashboard: 'Dashboard', users: 'Manage Users', orders: 'Manage Orders',
  categories: 'Manage Categories', services: 'Manage Services',
  banners: 'Manage Banners', announcements: 'Manage Announcements',
  channels: 'Force Join Channels', settings: 'Settings',
};

function setPage(pageName) {
  ADMIN.page = pageName;
  document.getElementById('pageTitle').textContent = PAGE_TITLES[pageName] || pageName;
  document.querySelectorAll('.sidebar-link').forEach(l => l.classList.toggle('active', l.dataset.page === pageName));
  document.getElementById('sidebar').classList.remove('open'); // close mobile sidebar
  renderPage(pageName);
}

document.querySelectorAll('.sidebar-link[data-page]').forEach(link => {
  link.addEventListener('click', () => setPage(link.dataset.page));
});

// ─────────────────────────────────────────────────────────────
// RENDER PAGES
// ─────────────────────────────────────────────────────────────
async function renderPage(page) {
  const content = document.getElementById('adminContent');
  content.innerHTML = '<div style="padding:40px;text-align:center;color:var(--text-4)"><i class="fas fa-spinner fa-spin" style="font-size:24px"></i></div>';

  switch (page) {
    case 'dashboard':     return renderDashboard(content);
    case 'users':         return renderUsers(content, 1, '');
    case 'orders':        return renderOrders(content, 1, '');
    case 'categories':    return renderCategories(content);
    case 'services':      return renderServices(content, 1);
    case 'banners':       return renderBanners(content);
    case 'announcements': return renderAnnouncements(content);
    case 'channels':      return renderChannels(content);
    case 'settings':      return renderSettings(content);
    default:              content.innerHTML = '<p>Page not found.</p>';
  }
}

// ── DASHBOARD ──────────────────────────────────────────────
async function renderDashboard(el) {
  const data = await api('/api/admin/dashboard');
  if (data.status !== 'success') { el.innerHTML = `<p style="color:var(--danger)">${escHtml(data.message)}</p>`; return; }

  const s = data.stats;
  el.innerHTML = `
    <div class="stats-grid">
      ${statCard('fa-users','#dbeafe','#2563eb','Total Users', fmtNum(s.total_users))}
      ${statCard('fa-bag-shopping','#dcfce7','#16a34a','Total Orders', fmtNum(s.total_orders))}
      ${statCard('fa-money-bill-wave','#fef3c7','#d97706','Revenue', fmtMoney(s.total_revenue))}
      ${statCard('fa-clock','#fee2e2','#dc2626','Pending Orders', fmtNum(s.pending_orders))}
      ${statCard('fa-list-check','#f3e8ff','#7c3aed','Services', fmtNum(s.total_services))}
      ${statCard('fa-calendar-day','#e0f2fe','#0369a1',"Today's Orders", fmtNum(s.today_orders))}
    </div>

    <div class="table-card">
      <div class="table-header">
        <span class="table-title"><i class="fas fa-clock" style="color:var(--primary);margin-right:6px"></i>Recent Orders</span>
        <button class="btn btn-ghost btn-sm" onclick="setPage('orders')">View All</button>
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr>
            <th>#ID</th><th>User</th><th>Service</th><th>Qty</th><th>Charge</th><th>Status</th><th>Date</th>
          </tr></thead>
          <tbody>
            ${(data.recent_orders || []).map(o => `
              <tr>
                <td class="td-mono">#${o.id}</td>
                <td><span class="td-name">${escHtml(o.first_name||'')}</span><br><small class="text-muted">@${escHtml(o.username||'')}</small></td>
                <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${escHtml(o.service_name)}</td>
                <td class="td-mono">${fmtNum(o.quantity)}</td>
                <td class="td-mono">${fmtMoney(o.charge)}</td>
                <td>${badge(o.status)}</td>
                <td class="text-muted" style="font-size:12px">${fmtDate(o.created_at)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

function statCard(icon, bg, color, label, val) {
  return `
    <div class="stat-card">
      <div class="stat-icon" style="background:${bg};color:${color}"><i class="fas ${icon}"></i></div>
      <div class="stat-body">
        <div class="stat-value">${val}</div>
        <div class="stat-label">${label}</div>
      </div>
    </div>`;
}

// ── USERS ──────────────────────────────────────────────────
async function renderUsers(el, page, search) {
  const params = new URLSearchParams({ page, ...(search ? { search } : {}) });
  const data   = await api(`/api/admin/users?${params}`);
  if (data.status !== 'success') { el.innerHTML = `<p style="color:var(--danger)">${escHtml(data.message)}</p>`; return; }

  el.innerHTML = `
    <div class="table-card">
      <div class="table-header">
        <span class="table-title">Users (${fmtNum(data.total)})</span>
        <div class="filter-bar">
          <div class="search-field">
            <i class="fas fa-search"></i>
            <input type="text" id="userSearch" placeholder="Search users..." value="${escHtml(search)}">
          </div>
          <button class="btn btn-primary btn-sm" id="userSearchBtn"><i class="fas fa-search"></i> Search</button>
        </div>
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>ID</th><th>User</th><th>Balance</th><th>Orders</th><th>Status</th><th>Joined</th><th>Actions</th></tr></thead>
          <tbody>
            ${(data.users || []).map(u => `
              <tr>
                <td class="td-mono">${u.id}</td>
                <td>
                  <span class="td-name">${escHtml(u.first_name||'')} ${escHtml(u.last_name||'')}</span><br>
                  <small class="text-muted">@${escHtml(u.username||'')} · ${escHtml(u.tg_id)}</small>
                </td>
                <td class="td-mono">${fmtMoney(u.balance)}</td>
                <td class="td-mono">${fmtNum(u.total_orders)}</td>
                <td>${badge(u.status)}</td>
                <td class="text-muted" style="font-size:12px">${fmtDate(u.created_at)}</td>
                <td>
                  <div class="td-actions">
                    <button class="btn-icon success" title="Add/Remove Balance" onclick="openBalanceModal(${u.id},'${escHtml(u.first_name||'')}')"><i class="fas fa-wallet"></i></button>
                    <button class="btn-icon ${u.status==='blocked'?'success':'danger'}" title="${u.status==='blocked'?'Unblock':'Block'}" onclick="toggleUserBlock(${u.id},'${u.status}')"><i class="fas fa-${u.status==='blocked'?'unlock':'ban'}"></i></button>
                  </div>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
      ${pagination(data.page, data.pages, p => renderUsers(el, p, search))}
    </div>
  `;

  bindPagination(el, p => renderUsers(el, p, search));
  document.getElementById('userSearchBtn').addEventListener('click', () => {
    renderUsers(el, 1, document.getElementById('userSearch').value.trim());
  });
  document.getElementById('userSearch').addEventListener('keydown', e => {
    if (e.key === 'Enter') renderUsers(el, 1, e.target.value.trim());
  });
}

function openBalanceModal(userId, name) {
  openModal(`Balance — ${name}`, `
    <div class="form-row">
      <label class="form-label">Action</label>
      <select class="form-select" id="balAction">
        <option value="add">Add Balance</option>
        <option value="remove">Remove Balance</option>
      </select>
    </div>
    <div class="form-row">
      <label class="form-label">Amount (৳)</label>
      <input type="number" class="form-input" id="balAmount" placeholder="0.00" min="0">
    </div>
    <div class="form-row">
      <label class="form-label">Note (optional)</label>
      <input type="text" class="form-input" id="balNote" placeholder="Reason...">
    </div>
  `, async () => {
    const amount = parseFloat(document.getElementById('balAmount').value || 0);
    const type   = document.getElementById('balAction').value;
    const note   = document.getElementById('balNote').value;
    if (!amount || amount <= 0) { toast('Enter a valid amount.', 'warning'); return; }
    const res = await api('/api/admin/users/balance', {
      method: 'POST',
      body: { user_id: userId, amount, type, note },
    });
    if (res.status === 'success') { toast(`Balance updated. New: ${fmtMoney(res.new_balance)}`); closeModal(); renderUsers(document.getElementById('adminContent'), 1, ''); }
    else toast(res.message || 'Failed.', 'danger');
  }, 'Update Balance');
}

async function toggleUserBlock(userId, currentStatus) {
  const action = currentStatus === 'blocked' ? 'unblock' : 'block';
  const msg    = action === 'block' ? prompt('Block message (shown to user):') : '';
  if (action === 'block' && msg === null) return; // cancelled
  const res = await api('/api/admin/users/block', {
    method: 'POST',
    body: { user_id: userId, action, message: msg || '' },
  });
  if (res.status === 'success') { toast(`User ${action}ed.`); renderUsers(document.getElementById('adminContent'), 1, ''); }
  else toast(res.message || 'Failed.', 'danger');
}

// ── ORDERS ──────────────────────────────────────────────────
async function renderOrders(el, page, status) {
  const params = new URLSearchParams({ page, ...(status ? { status } : {}) });
  const data   = await api(`/api/admin/orders?${params}`);
  if (data.status !== 'success') { el.innerHTML = `<p style="color:var(--danger)">${escHtml(data.message)}</p>`; return; }

  const statusOpts = ['', 'pending','processing','completed','partial','cancelled','refunded']
    .map(s => `<option value="${s}" ${s===status?'selected':''}>${s||'All'}</option>`).join('');

  el.innerHTML = `
    <div class="table-card">
      <div class="table-header">
        <span class="table-title">Orders (${fmtNum(data.total)})</span>
        <div class="filter-bar">
          <select class="filter-select" id="orderStatusFilter">${statusOpts}</select>
          <button class="btn btn-primary btn-sm" id="orderFilterBtn"><i class="fas fa-filter"></i> Filter</button>
        </div>
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>#</th><th>User</th><th>Service</th><th>Link</th><th>Qty</th><th>Charge</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
          <tbody>
            ${(data.orders || []).map(o => `
              <tr>
                <td class="td-mono">${o.id}</td>
                <td><span class="td-name">${escHtml(o.first_name||'')}</span><br><small class="text-muted">@${escHtml(o.username||'')}</small></td>
                <td style="max-width:140px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12px">${escHtml(o.service_name)}</td>
                <td style="max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:11px">
                  <a href="${escHtml(o.link||'#')}" target="_blank" style="color:var(--primary)">${escHtml((o.link||'').slice(0,30))}...</a>
                </td>
                <td class="td-mono">${fmtNum(o.quantity)}</td>
                <td class="td-mono">${fmtMoney(o.charge)}</td>
                <td>${badge(o.status)}</td>
                <td class="text-muted" style="font-size:12px">${fmtDate(o.created_at)}</td>
                <td>
                  <button class="btn-icon" title="Update Status" onclick="openOrderModal(${o.id},'${escHtml(o.status)}')"><i class="fas fa-pen"></i></button>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
      ${pagination(data.page, data.pages, p => renderOrders(el, p, status))}
    </div>
  `;

  bindPagination(el, p => renderOrders(el, p, status));
  document.getElementById('orderFilterBtn').addEventListener('click', () => {
    renderOrders(el, 1, document.getElementById('orderStatusFilter').value);
  });
}

function openOrderModal(orderId, currentStatus) {
  const statuses = ['pending','processing','completed','partial','cancelled','refunded'];
  openModal(`Update Order #${orderId}`, `
    <div class="form-row">
      <label class="form-label">Status</label>
      <select class="form-select" id="orderStatus">
        ${statuses.map(s => `<option value="${s}" ${s===currentStatus?'selected':''}>${s}</option>`).join('')}
      </select>
    </div>
    <div class="form-row">
      <label class="form-label">Admin Note (optional)</label>
      <input type="text" class="form-input" id="orderNote" placeholder="Internal note...">
    </div>
  `, async () => {
    const res = await api(`/api/admin/orders?id=${orderId}`, {
      method: 'PUT',
      body: { status: document.getElementById('orderStatus').value, note: document.getElementById('orderNote').value },
    });
    if (res.status === 'success') { toast('Order updated.'); closeModal(); renderOrders(document.getElementById('adminContent'), 1, ''); }
    else toast(res.message || 'Failed.', 'danger');
  }, 'Update Order');
}

// ── CATEGORIES ──────────────────────────────────────────────
async function renderCategories(el) {
  const data = await api('/api/admin/categories');
  if (data.status !== 'success') { el.innerHTML = `<p style="color:var(--danger)">${escHtml(data.message)}</p>`; return; }

  const PLATFORMS = ['all','facebook','youtube','tiktok','instagram','telegram','twitter','x'];

  el.innerHTML = `
    <div class="table-card">
      <div class="table-header">
        <span class="table-title">Categories (${(data.categories||[]).length})</span>
        <button class="btn btn-primary btn-sm" id="addCatBtn"><i class="fas fa-plus"></i> Add Category</button>
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>ID</th><th>Name</th><th>Platform</th><th>Order</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
            ${(data.categories||[]).map(c => `
              <tr>
                <td class="td-mono">${c.id}</td>
                <td class="td-name">${escHtml(c.name)}</td>
                <td>${escHtml(c.platform_key)}</td>
                <td class="td-mono">${c.sort_order}</td>
                <td>${badge(c.status)}</td>
                <td>
                  <div class="td-actions">
                    <button class="btn-icon" onclick="openCatModal(${c.id},'${escHtml(c.name)}','${escHtml(c.platform_key)}',${c.sort_order},'${escHtml(c.status)}')"><i class="fas fa-pen"></i></button>
                    <button class="btn-icon danger" onclick="deleteCategory(${c.id})"><i class="fas fa-trash"></i></button>
                  </div>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;

  function catFormHtml(name='',platform='all',order=0,status='active') {
    return `
      <div class="form-row"><label class="form-label">Category Name</label><input type="text" class="form-input" id="catName" value="${escHtml(name)}" placeholder="Category name"></div>
      <div class="form-2col">
        <div class="form-row"><label class="form-label">Platform</label>
          <select class="form-select" id="catPlatform">${PLATFORMS.map(p=>`<option value="${p}" ${p===platform?'selected':''}>${p}</option>`).join('')}</select>
        </div>
        <div class="form-row"><label class="form-label">Sort Order</label><input type="number" class="form-input" id="catOrder" value="${order}"></div>
      </div>
      <div class="form-row"><label class="form-label">Status</label>
        <select class="form-select" id="catStatus"><option value="active" ${status==='active'?'selected':''}>Active</option><option value="hidden" ${status==='hidden'?'selected':''}>Hidden</option></select>
      </div>`;
  }

  document.getElementById('addCatBtn').addEventListener('click', () => {
    openModal('Add Category', catFormHtml(), async () => {
      const res = await api('/api/admin/categories', { method: 'POST', body: {
        name: document.getElementById('catName').value,
        platform_key: document.getElementById('catPlatform').value,
        sort_order: parseInt(document.getElementById('catOrder').value||0),
        status: document.getElementById('catStatus').value,
      }});
      if (res.status === 'success') { toast('Category created.'); closeModal(); renderCategories(el); }
      else toast(res.message||'Failed.','danger');
    }, 'Create');
  });

  window.openCatModal = (id, name, platform, order, status) => {
    openModal('Edit Category', catFormHtml(name, platform, order, status), async () => {
      const res = await api(`/api/admin/categories?id=${id}`, { method: 'PUT', body: {
        name: document.getElementById('catName').value,
        platform_key: document.getElementById('catPlatform').value,
        sort_order: parseInt(document.getElementById('catOrder').value||0),
        status: document.getElementById('catStatus').value,
      }});
      if (res.status === 'success') { toast('Category updated.'); closeModal(); renderCategories(el); }
      else toast(res.message||'Failed.','danger');
    }, 'Save Changes');
  };

  window.deleteCategory = async (id) => {
    if (!confirm('Delete this category?')) return;
    const res = await api(`/api/admin/categories?id=${id}`, { method: 'DELETE' });
    if (res.status === 'success') { toast('Deleted.'); renderCategories(el); }
    else toast(res.message||'Failed.','danger');
  };
}

// ── SERVICES ──────────────────────────────────────────────
async function renderServices(el, page) {
  const [svcData, catData] = await Promise.all([
    api(`/api/admin/services?page=${page}`),
    api('/api/admin/categories'),
  ]);

  if (svcData.status !== 'success') { el.innerHTML = `<p style="color:var(--danger)">${escHtml(svcData.message)}</p>`; return; }

  const categories = catData.categories || [];
  const catMap = {};
  categories.forEach(c => { catMap[c.id] = c.name; });

  el.innerHTML = `
    <div class="table-card">
      <div class="table-header">
        <span class="table-title">Services (${fmtNum(svcData.total)})</span>
        <button class="btn btn-primary btn-sm" id="addSvcBtn"><i class="fas fa-plus"></i> Add Service</button>
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>ID</th><th>Name</th><th>Category</th><th>Rate/1K</th><th>Min/Max</th><th>Vis. ID</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
            ${(svcData.services||[]).map(s => `
              <tr>
                <td class="td-mono">${s.id}</td>
                <td style="max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:700">${escHtml(s.name)}</td>
                <td style="font-size:12px">${escHtml(catMap[s.category_id]||'—')}</td>
                <td class="td-mono">${fmtMoney(s.rate_per_1000)}</td>
                <td class="td-mono" style="font-size:12px">${fmtNum(s.min_qty)} / ${fmtNum(s.max_qty)}</td>
                <td class="td-mono">${escHtml(s.visible_service_id||'—')}</td>
                <td>${badge(s.status)}</td>
                <td>
                  <button class="btn-icon" onclick="openSvcModal(${JSON.stringify(s).replace(/"/g,'&quot;')})"><i class="fas fa-pen"></i></button>
                  <button class="btn-icon danger" onclick="deleteSvc(${s.id})"><i class="fas fa-eye-slash"></i></button>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
      ${pagination(svcData.page||page, svcData.pages||1, p => renderServices(el, p))}
    </div>
  `;

  bindPagination(el, p => renderServices(el, p));

  function svcFormHtml(s = {}) {
    const catOpts = categories.map(c => `<option value="${c.id}" ${Number(c.id)===Number(s.category_id)?'selected':''}>${escHtml(c.name)}</option>`).join('');
    const types   = ['default','custom_comments','mentions'].map(t => `<option value="${t}" ${t===s.service_type?'selected':''}>${t}</option>`).join('');
    const statuses= ['active','hidden'].map(t => `<option value="${t}" ${t===s.status?'selected':''}>${t}</option>`).join('');
    return `
      <div class="form-row"><label class="form-label">Service Name</label><input type="text" class="form-input" id="svcName" value="${escHtml(s.name||'')}"></div>
      <div class="form-row"><label class="form-label">Category</label><select class="form-select" id="svcCat">${catOpts}</select></div>
      <div class="form-row"><label class="form-label">Description</label><textarea class="form-textarea" id="svcDesc">${escHtml(s.description||'')}</textarea></div>
      <div class="form-2col">
        <div class="form-row"><label class="form-label">Rate per 1000 (৳)</label><input type="number" step="0.0001" class="form-input" id="svcRate" value="${s.rate_per_1000||0}"></div>
        <div class="form-row"><label class="form-label">Visible Service ID</label><input type="text" class="form-input" id="svcVisId" value="${escHtml(s.visible_service_id||'')}"></div>
      </div>
      <div class="form-2col">
        <div class="form-row"><label class="form-label">Min Qty</label><input type="number" class="form-input" id="svcMin" value="${s.min_qty||100}"></div>
        <div class="form-row"><label class="form-label">Max Qty</label><input type="number" class="form-input" id="svcMax" value="${s.max_qty||100000}"></div>
      </div>
      <div class="form-2col">
        <div class="form-row"><label class="form-label">Service Type</label><select class="form-select" id="svcType">${types}</select></div>
        <div class="form-row"><label class="form-label">Avg. Time</label><input type="text" class="form-input" id="svcTime" value="${escHtml(s.avg_time||'')}" placeholder="e.g. 1-2 hours"></div>
      </div>
      <div class="form-2col">
        <div class="form-row"><label class="form-label">Sort Order</label><input type="number" class="form-input" id="svcOrder" value="${s.sort_order||0}"></div>
        <div class="form-row"><label class="form-label">Status</label><select class="form-select" id="svcStatus">${statuses}</select></div>
      </div>
    `;
  }

  function collectSvcForm() {
    return {
      name: document.getElementById('svcName').value,
      category_id: document.getElementById('svcCat').value,
      description: document.getElementById('svcDesc').value,
      rate_per_1000: parseFloat(document.getElementById('svcRate').value||0),
      visible_service_id: document.getElementById('svcVisId').value,
      min_qty: parseInt(document.getElementById('svcMin').value||100),
      max_qty: parseInt(document.getElementById('svcMax').value||100000),
      service_type: document.getElementById('svcType').value,
      avg_time: document.getElementById('svcTime').value,
      sort_order: parseInt(document.getElementById('svcOrder').value||0),
      status: document.getElementById('svcStatus').value,
    };
  }

  document.getElementById('addSvcBtn').addEventListener('click', () => {
    openModal('Add Service', svcFormHtml(), async () => {
      const res = await api('/api/admin/services', { method: 'POST', body: collectSvcForm() });
      if (res.status === 'success') { toast('Service created.'); closeModal(); renderServices(el, 1); }
      else toast(res.message||'Failed.','danger');
    }, 'Create Service');
  });

  window.openSvcModal = sObj => {
    openModal('Edit Service', svcFormHtml(sObj), async () => {
      const res = await api(`/api/admin/services?id=${sObj.id}`, { method: 'PUT', body: collectSvcForm() });
      if (res.status === 'success') { toast('Service updated.'); closeModal(); renderServices(el, page); }
      else toast(res.message||'Failed.','danger');
    }, 'Save Changes');
  };

  window.deleteSvc = async (id) => {
    if (!confirm('Hide this service?')) return;
    const res = await api(`/api/admin/services?id=${id}`, { method: 'DELETE' });
    if (res.status === 'success') { toast('Service hidden.'); renderServices(el, page); }
    else toast(res.message||'Failed.','danger');
  };
}

// ── BANNERS ────────────────────────────────────────────────
async function renderBanners(el) {
  const data = await api('/api/admin/banners');
  if (data.status !== 'success') { el.innerHTML = `<p style="color:var(--danger)">${escHtml(data.message)}</p>`; return; }

  el.innerHTML = `
    <div class="table-card">
      <div class="table-header">
        <span class="table-title">Banners (${(data.banners||[]).length})</span>
        <button class="btn btn-primary btn-sm" id="addBannerBtn"><i class="fas fa-plus"></i> Add Banner</button>
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>ID</th><th>Preview</th><th>Title</th><th>Link</th><th>Order</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
            ${(data.banners||[]).map(b => `
              <tr>
                <td class="td-mono">${b.id}</td>
                <td><img src="${escHtml(b.image_url)}" style="width:80px;height:45px;object-fit:cover;border-radius:6px;border:1px solid var(--border)"></td>
                <td class="td-name">${escHtml(b.title||'—')}</td>
                <td style="max-width:120px;overflow:hidden;text-overflow:ellipsis;font-size:12px"><a href="${escHtml(b.link_url||'#')}" target="_blank" style="color:var(--primary)">${escHtml(b.link_url||'—')}</a></td>
                <td class="td-mono">${b.sort_order}</td>
                <td>${badge(b.status)}</td>
                <td>
                  <button class="btn-icon" onclick="openBannerModal(${b.id},'${escHtml(b.title||'')}','${escHtml(b.image_url)}','${escHtml(b.link_url||'')}',${b.sort_order},'${escHtml(b.status)}')"><i class="fas fa-pen"></i></button>
                  <button class="btn-icon danger" onclick="deleteBanner(${b.id})"><i class="fas fa-trash"></i></button>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;

  function bannerForm(title='',url='',link='',order=0,status='active') {
    return `
      <div class="form-row"><label class="form-label">Title</label><input type="text" class="form-input" id="bTitle" value="${escHtml(title)}"></div>
      <div class="form-row"><label class="form-label">Image URL</label><input type="url" class="form-input" id="bUrl" value="${escHtml(url)}" placeholder="https://..."></div>
      <div class="form-row"><label class="form-label">Link URL (optional)</label><input type="url" class="form-input" id="bLink" value="${escHtml(link)}" placeholder="https://..."></div>
      <div class="form-2col">
        <div class="form-row"><label class="form-label">Sort Order</label><input type="number" class="form-input" id="bOrder" value="${order}"></div>
        <div class="form-row"><label class="form-label">Status</label><select class="form-select" id="bStatus"><option value="active" ${status==='active'?'selected':''}>Active</option><option value="hidden" ${status==='hidden'?'selected':''}>Hidden</option></select></div>
      </div>`;
  }

  function collectBanner() { return { title:document.getElementById('bTitle').value, image_url:document.getElementById('bUrl').value, link_url:document.getElementById('bLink').value, sort_order:parseInt(document.getElementById('bOrder').value||0), status:document.getElementById('bStatus').value }; }

  document.getElementById('addBannerBtn').addEventListener('click', () => {
    openModal('Add Banner', bannerForm(), async () => {
      const res = await api('/api/admin/banners', { method:'POST', body:collectBanner() });
      if (res.status==='success') { toast('Banner added.'); closeModal(); renderBanners(el); }
      else toast(res.message||'Failed.','danger');
    }, 'Add');
  });

  window.openBannerModal = (id,title,url,link,order,status) => {
    openModal('Edit Banner', bannerForm(title,url,link,order,status), async () => {
      const res = await api(`/api/admin/banners?id=${id}`, { method:'PUT', body:collectBanner() });
      if (res.status==='success') { toast('Banner updated.'); closeModal(); renderBanners(el); }
      else toast(res.message||'Failed.','danger');
    },'Save');
  };

  window.deleteBanner = async (id) => {
    if (!confirm('Delete banner?')) return;
    const res = await api(`/api/admin/banners?id=${id}`, { method:'DELETE' });
    if (res.status==='success') { toast('Deleted.'); renderBanners(el); }
    else toast(res.message||'Failed.','danger');
  };
}

// ── ANNOUNCEMENTS ─────────────────────────────────────────
async function renderAnnouncements(el) {
  const data = await api('/api/admin/announcements');
  if (data.status !== 'success') { el.innerHTML = `<p style="color:var(--danger)">${escHtml(data.message)}</p>`; return; }

  el.innerHTML = `
    <div class="table-card">
      <div class="table-header">
        <span class="table-title">Announcements (${(data.announcements||[]).length})</span>
        <button class="btn btn-primary btn-sm" id="addAnnBtn"><i class="fas fa-plus"></i> Add</button>
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>ID</th><th>Title</th><th>Content</th><th>Type</th><th>Order</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
            ${(data.announcements||[]).map(a => `
              <tr>
                <td class="td-mono">${a.id}</td>
                <td class="td-name">${escHtml(a.title)}</td>
                <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12px">${escHtml(a.content)}</td>
                <td><span class="badge badge-${a.type==='success'?'completed':a.type==='warning'?'pending':a.type==='danger'?'cancelled':'processing'}">${escHtml(a.type)}</span></td>
                <td class="td-mono">${a.sort_order}</td>
                <td>${badge(a.status)}</td>
                <td>
                  <button class="btn-icon" onclick="openAnnModal(${a.id},'${escHtml(a.title)}',\`${escHtml(a.content)}\`,'${escHtml(a.type)}',${a.sort_order},'${escHtml(a.status)}')"><i class="fas fa-pen"></i></button>
                  <button class="btn-icon danger" onclick="deleteAnn(${a.id})"><i class="fas fa-trash"></i></button>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;

  function annForm(title='',content='',type='info',order=0,status='active') {
    const types=['info','success','warning','danger'].map(t=>`<option value="${t}" ${t===type?'selected':''}>${t}</option>`).join('');
    return `
      <div class="form-row"><label class="form-label">Title</label><input type="text" class="form-input" id="aTitle" value="${escHtml(title)}"></div>
      <div class="form-row"><label class="form-label">Content</label><textarea class="form-textarea" id="aContent">${escHtml(content)}</textarea></div>
      <div class="form-2col">
        <div class="form-row"><label class="form-label">Type</label><select class="form-select" id="aType">${types}</select></div>
        <div class="form-row"><label class="form-label">Sort Order</label><input type="number" class="form-input" id="aOrder" value="${order}"></div>
      </div>
      <div class="form-row"><label class="form-label">Status</label><select class="form-select" id="aStatus"><option value="active" ${status==='active'?'selected':''}>Active</option><option value="hidden" ${status==='hidden'?'selected':''}>Hidden</option></select></div>
    `;
  }

  function collectAnn() { return { title:document.getElementById('aTitle').value, content:document.getElementById('aContent').value, type:document.getElementById('aType').value, sort_order:parseInt(document.getElementById('aOrder').value||0), status:document.getElementById('aStatus').value }; }

  document.getElementById('addAnnBtn').addEventListener('click', () => {
    openModal('Add Announcement', annForm(), async () => {
      const res = await api('/api/admin/announcements', { method:'POST', body:collectAnn() });
      if (res.status==='success') { toast('Created.'); closeModal(); renderAnnouncements(el); }
      else toast(res.message||'Failed.','danger');
    },'Create');
  });

  window.openAnnModal = (id,title,content,type,order,status) => {
    openModal('Edit Announcement', annForm(title,content,type,order,status), async () => {
      const res = await api(`/api/admin/announcements?id=${id}`, { method:'PUT', body:collectAnn() });
      if (res.status==='success') { toast('Updated.'); closeModal(); renderAnnouncements(el); }
      else toast(res.message||'Failed.','danger');
    },'Save');
  };

  window.deleteAnn = async (id) => {
    if (!confirm('Delete?')) return;
    const res = await api(`/api/admin/announcements?id=${id}`, { method:'DELETE' });
    if (res.status==='success') { toast('Deleted.'); renderAnnouncements(el); }
    else toast(res.message||'Failed.','danger');
  };
}

// ── CHANNELS ───────────────────────────────────────────────
async function renderChannels(el) {
  const data = await api('/api/admin/force-channels');
  if (data.status !== 'success') { el.innerHTML = `<p style="color:var(--danger)">${escHtml(data.message)}</p>`; return; }

  el.innerHTML = `
    <div class="table-card">
      <div class="table-header">
        <span class="table-title">Force Join Channels (${(data.channels||[]).length})</span>
        <button class="btn btn-primary btn-sm" id="addChBtn"><i class="fas fa-plus"></i> Add Channel</button>
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>ID</th><th>Title</th><th>Username</th><th>Channel ID</th><th>Order</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
            ${(data.channels||[]).map(c => `
              <tr>
                <td class="td-mono">${c.id}</td>
                <td class="td-name">${escHtml(c.title)}</td>
                <td class="td-mono">${escHtml(c.channel_username)}</td>
                <td class="td-mono" style="font-size:12px">${escHtml(c.channel_id)}</td>
                <td class="td-mono">${c.sort_order}</td>
                <td>${badge(c.status)}</td>
                <td>
                  <button class="btn-icon" onclick="openChModal(${c.id},'${escHtml(c.title)}','${escHtml(c.channel_username)}','${escHtml(c.channel_id)}','${escHtml(c.invite_link||'')}',${c.sort_order},'${escHtml(c.status)}')"><i class="fas fa-pen"></i></button>
                  <button class="btn-icon danger" onclick="deleteCh(${c.id})"><i class="fas fa-trash"></i></button>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;

  function chForm(title='',username='',chId='',link='',order=0,status='active') {
    return `
      <div class="form-row"><label class="form-label">Channel Title</label><input type="text" class="form-input" id="chTitle" value="${escHtml(title)}"></div>
      <div class="form-row"><label class="form-label">Username (with @)</label><input type="text" class="form-input" id="chUser" value="${escHtml(username)}" placeholder="@channelname"></div>
      <div class="form-row"><label class="form-label">Channel ID</label><input type="text" class="form-input" id="chId" value="${escHtml(chId)}" placeholder="-1001234567890"></div>
      <div class="form-row"><label class="form-label">Invite Link</label><input type="url" class="form-input" id="chLink" value="${escHtml(link)}" placeholder="https://t.me/..."></div>
      <div class="form-2col">
        <div class="form-row"><label class="form-label">Sort Order</label><input type="number" class="form-input" id="chOrder" value="${order}"></div>
        <div class="form-row"><label class="form-label">Status</label><select class="form-select" id="chStatus"><option value="active" ${status==='active'?'selected':''}>Active</option><option value="hidden" ${status==='hidden'?'selected':''}>Hidden</option></select></div>
      </div>`;
  }

  function collectCh() { return { title:document.getElementById('chTitle').value, channel_username:document.getElementById('chUser').value, channel_id:document.getElementById('chId').value, invite_link:document.getElementById('chLink').value, sort_order:parseInt(document.getElementById('chOrder').value||0), status:document.getElementById('chStatus').value }; }

  document.getElementById('addChBtn').addEventListener('click', () => {
    openModal('Add Force Channel', chForm(), async () => {
      const res = await api('/api/admin/force-channels', { method:'POST', body:collectCh() });
      if (res.status==='success') { toast('Channel added.'); closeModal(); renderChannels(el); }
      else toast(res.message||'Failed.','danger');
    },'Add Channel');
  });

  window.openChModal = (id,title,user,chId,link,order,status) => {
    openModal('Edit Channel', chForm(title,user,chId,link,order,status), async () => {
      const res = await api(`/api/admin/force-channels?id=${id}`, { method:'PUT', body:collectCh() });
      if (res.status==='success') { toast('Updated.'); closeModal(); renderChannels(el); }
      else toast(res.message||'Failed.','danger');
    },'Save');
  };

  window.deleteCh = async (id) => {
    if (!confirm('Delete channel?')) return;
    const res = await api(`/api/admin/force-channels?id=${id}`, { method:'DELETE' });
    if (res.status==='success') { toast('Deleted.'); renderChannels(el); }
    else toast(res.message||'Failed.','danger');
  };
}

// ── SETTINGS ───────────────────────────────────────────────
async function renderSettings(el) {
  const data = await api('/api/admin/settings');
  if (data.status !== 'success') { el.innerHTML = `<p style="color:var(--danger)">${escHtml(data.message)}</p>`; return; }
  const s = data.settings || {};

  el.innerHTML = `
    <div style="max-width:640px">
      <div class="table-card" style="margin-bottom:16px">
        <div class="table-header"><span class="table-title">General Settings</span></div>
        <div style="padding:20px">
          <div class="form-row"><label class="form-label">Site Name</label><input type="text" class="form-input" id="sSiteName" value="${escHtml(s.site_name||'')}"></div>
          <div class="form-row"><label class="form-label">Currency Symbol</label><input type="text" class="form-input" id="sCurrency" value="${escHtml(s.currency_symbol||'৳')}" style="max-width:80px"></div>
          <div class="form-row"><label class="form-label">Admin Contact Link</label><input type="url" class="form-input" id="sAdminContact" value="${escHtml(s.admin_contact||'')}"></div>
          <div class="form-row"><label class="form-label">Running Text / Announcement Marquee</label><textarea class="form-textarea" id="sRunningText">${escHtml(s.running_text||'')}</textarea></div>
        </div>
      </div>

      <div class="table-card" style="margin-bottom:16px">
        <div class="table-header"><span class="table-title">Telegram Bot</span></div>
        <div style="padding:20px">
          <div class="form-row"><label class="form-label">Bot Token</label><input type="password" class="form-input" id="sBotToken" value="${escHtml(s.bot_token||'')}" placeholder="Enter bot token (stored securely)"></div>
          <div class="form-row"><label class="form-label">Bot Username</label><input type="text" class="form-input" id="sBotUser" value="${escHtml(s.bot_username||'')}"></div>
        </div>
      </div>

      <div class="table-card" style="margin-bottom:16px">
        <div class="table-header"><span class="table-title">Features</span></div>
        <div style="padding:20px;display:flex;flex-direction:column;gap:14px">
          ${toggleRow('referral_enabled', s.referral_enabled, 'Referral System')}
          ${toggleRow('deposit_enabled',  s.deposit_enabled,  'Deposit System')}
          ${toggleRow('order_enabled',    s.order_enabled,    'Order Placement')}
          ${toggleRow('maintenance_mode', s.maintenance_mode, 'Maintenance Mode')}
        </div>
        <div style="padding:0 20px 20px">
          <div class="form-row"><label class="form-label">Maintenance Message</label><textarea class="form-textarea" id="sMaintenanceMsg">${escHtml(s.maintenance_msg||'')}</textarea></div>
        </div>
      </div>

      <div class="table-card" style="margin-bottom:16px">
        <div class="table-header"><span class="table-title">Referral Bonus</span></div>
        <div style="padding:20px">
          <div class="form-row"><label class="form-label">Referral Bonus Amount (৳)</label><input type="number" step="0.01" class="form-input" id="sRefBonus" value="${escHtml(s.referral_bonus||'0')}" style="max-width:160px"></div>
          <div class="form-row"><label class="form-label">Minimum Deposit (৳)</label><input type="number" step="1" class="form-input" id="sMinDeposit" value="${escHtml(s.min_deposit||'50')}" style="max-width:160px"></div>
        </div>
      </div>

      <button class="btn btn-primary" id="saveSettingsBtn" style="width:100%">
        <i class="fas fa-save"></i> Save All Settings
      </button>
    </div>
  `;

  document.getElementById('saveSettingsBtn').addEventListener('click', async () => {
    const body = {
      site_name:        document.getElementById('sSiteName').value,
      currency_symbol:  document.getElementById('sCurrency').value,
      admin_contact:    document.getElementById('sAdminContact').value,
      running_text:     document.getElementById('sRunningText').value,
      bot_token:        document.getElementById('sBotToken').value,
      bot_username:     document.getElementById('sBotUser').value,
      referral_bonus:   document.getElementById('sRefBonus').value,
      min_deposit:      document.getElementById('sMinDeposit').value,
      maintenance_msg:  document.getElementById('sMaintenanceMsg').value,
    };
    // Collect toggles
    document.querySelectorAll('.settings-toggle').forEach(t => {
      body[t.dataset.key] = t.checked ? '1' : '0';
    });

    const res = await api('/api/admin/settings', { method:'POST', body });
    if (res.status==='success') toast('Settings saved.');
    else toast(res.message||'Failed.','danger');
  });
}

function toggleRow(key, val, label) {
  return `
    <label style="display:flex;align-items:center;justify-content:space-between;cursor:pointer">
      <span style="font-weight:600;font-size:13px">${escHtml(label)}</span>
      <input type="checkbox" class="settings-toggle" data-key="${key}" ${val==='1'?'checked':''} style="width:18px;height:18px;cursor:pointer">
    </label>`;
}

// ─────────────────────────────────────────────────────────────
// AUTH
// ─────────────────────────────────────────────────────────────
document.getElementById('loginBtn').addEventListener('click', async () => {
  const tgId  = document.getElementById('loginTgId').value.trim();
  const secret= document.getElementById('loginSecret').value.trim();
  const errEl = document.getElementById('loginError');
  errEl.classList.remove('show');

  if (!tgId || !secret) { errEl.textContent = 'Please fill all fields.'; errEl.classList.add('show'); return; }

  const btn = document.getElementById('loginBtn');
  btn.disabled = true;
  btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Logging in...';

  const res = await api('/api/admin/login', {
    method: 'POST',
    body: { tg_id: tgId, secret },
  });

  btn.disabled = false;
  btn.innerHTML = '<i class="fas fa-sign-in-alt"></i> Login to Admin';

  if (res.status === 'success') {
    ADMIN.token   = res.token;
    ADMIN.profile = res.admin;
    localStorage.setItem('smm_admin_token', res.token);
    localStorage.setItem('smm_admin_info',  JSON.stringify(res.admin));
    bootAdmin();
  } else {
    errEl.textContent = res.message || 'Login failed.';
    errEl.classList.add('show');
  }
});

// Enter key on login
document.getElementById('loginSecret').addEventListener('keydown', e => {
  if (e.key === 'Enter') document.getElementById('loginBtn').click();
});

function bootAdmin() {
  document.getElementById('loginScreen').classList.add('hidden');
  document.getElementById('adminLayout').classList.remove('hidden');
  document.getElementById('sidebarAdminName').textContent = ADMIN.profile?.name || 'Admin';
  document.getElementById('sidebarAdminRole').textContent = ADMIN.profile?.role || 'admin';
  setPage('dashboard');
}

document.getElementById('logoutBtn').addEventListener('click', () => {
  ADMIN.token = '';
  localStorage.removeItem('smm_admin_token');
  localStorage.removeItem('smm_admin_info');
  document.getElementById('adminLayout').classList.add('hidden');
  document.getElementById('loginScreen').classList.remove('hidden');
});

// Mobile sidebar toggle
document.getElementById('sidebarToggle').addEventListener('click', () => {
  document.getElementById('sidebar').classList.toggle('open');
});

// Responsive sidebar toggle visibility
function updateSidebarToggle() {
  document.getElementById('sidebarToggle').style.display = window.innerWidth <= 768 ? 'flex' : 'none';
}
window.addEventListener('resize', updateSidebarToggle);
updateSidebarToggle();

// ─────────────────────────────────────────────────────────────
// AUTO-LOGIN IF TOKEN EXISTS
// ─────────────────────────────────────────────────────────────
if (ADMIN.token) {
  // Verify token is still valid
  api('/api/admin/dashboard').then(res => {
    if (res.status === 'success') {
      bootAdmin();
    } else {
      localStorage.removeItem('smm_admin_token');
      ADMIN.token = '';
    }
  });
}
