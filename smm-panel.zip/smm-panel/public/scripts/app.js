/**
 * app.js — User Panel Frontend Logic
 * SMM Panel v1.0.0
 *
 * Handles: Telegram auth, home data, order form, search,
 *          slider, marquee, force-join overlay, popups
 */

'use strict';

// ─────────────────────────────────────────────────────────────
// STATE
// ─────────────────────────────────────────────────────────────
const STATE = {
  tg:             window.Telegram?.WebApp || null,
  initData:       '',
  user:           null,
  balance:        0,
  homeData:       {},
  selectedPlatform: 'all',
  selectedService: null,
  sliderIndex:    0,
  sliderTimer:    null,
  searchIndex:    [],
  currency:       '৳',
};

// ─────────────────────────────────────────────────────────────
// TELEGRAM SETUP
// ─────────────────────────────────────────────────────────────
if (STATE.tg) {
  STATE.tg.expand();
  STATE.tg.enableClosingConfirmation();
  STATE.initData = STATE.tg.initData || '';
}

// ─────────────────────────────────────────────────────────────
// API HELPER
// ─────────────────────────────────────────────────────────────
const API_BASE = (window.SMM_CONFIG?.API_BASE || '').replace(/\/$/, '');

async function apiFetch(path, opts = {}) {
  const url     = `${API_BASE}${path}`;
  const method  = opts.method || 'GET';
  const headers = { 'Content-Type': 'application/json', ...(opts.headers || {}) };

  try {
    const res  = await fetch(url, {
      method,
      headers,
      body: opts.body ? JSON.stringify(opts.body) : undefined,
      signal: AbortSignal.timeout(15000),
    });
    return await res.json();
  } catch (e) {
    console.error('[API Error]', path, e);
    return { status: 'error', message: 'Network error. Please try again.' };
  }
}

// ─────────────────────────────────────────────────────────────
// POPUP SHEET
// ─────────────────────────────────────────────────────────────
const popupEl      = document.getElementById('popup');
const popupIconEl  = document.getElementById('popupIcon');
const popupTitleEl = document.getElementById('popupTitle');
const popupMsgEl   = document.getElementById('popupMessage');
const popupActionEl = document.getElementById('popupAction');
const popupCloseEl = document.getElementById('popupClose');

function showPopup(title, message, type = 'error', onAction = null) {
  popupTitleEl.textContent = title;
  popupMsgEl.textContent   = message;

  const iconMap = {
    error:   { icon: 'fa-circle-exclamation', cls: 'error' },
    success: { icon: 'fa-circle-check',       cls: 'success' },
    info:    { icon: 'fa-circle-info',         cls: 'info' },
    warning: { icon: 'fa-triangle-exclamation',cls: 'warning' },
  };
  const { icon, cls } = iconMap[type] || iconMap.error;
  popupIconEl.className = `popup-icon ${cls}`;
  popupIconEl.innerHTML = `<i class="fas ${icon}"></i>`;

  popupActionEl.onclick = () => { closePopup(); if (onAction) onAction(); };
  popupEl.classList.add('show');
}

function closePopup() { popupEl.classList.remove('show'); }

popupCloseEl.onclick  = closePopup;
popupActionEl.onclick = closePopup;
popupEl.addEventListener('click', e => { if (e.target === popupEl) closePopup(); });

// ─────────────────────────────────────────────────────────────
// FORMATTERS
// ─────────────────────────────────────────────────────────────
function fmtMoney(num) {
  return STATE.currency + Number(num || 0).toFixed(4);
}

function fmtMoneyShort(num) {
  const n = Number(num || 0);
  if (n >= 1000) return STATE.currency + (n / 1000).toFixed(2) + 'K';
  return STATE.currency + n.toFixed(2);
}

function escHtml(t) {
  const d = document.createElement('div');
  d.textContent = t ?? '';
  return d.innerHTML;
}

function timeAgo(ts) {
  const diff = Math.floor(Date.now() / 1000) - ts;
  if (diff < 60)     return 'Just now';
  if (diff < 3600)   return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400)  return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}

// ─────────────────────────────────────────────────────────────
// PLATFORM ICONS
// ─────────────────────────────────────────────────────────────
const PLATFORM_ICON_MAP = {
  facebook:  'fab fa-facebook-f',
  youtube:   'fab fa-youtube',
  tiktok:    'fab fa-tiktok',
  instagram: 'fab fa-instagram',
  telegram:  'fab fa-telegram-plane',
  twitter:   'fab fa-x-twitter',
  x:         'fab fa-x-twitter',
  all:       'fas fa-layer-group',
};

function getPlatformIcon(key) {
  return PLATFORM_ICON_MAP[String(key || '').toLowerCase()] || 'fas fa-globe';
}

function platformLogoHtml(key) {
  const k = String(key || 'default').toLowerCase();
  return `<span class="platform-logo p-${k}"><i class="${getPlatformIcon(k)}"></i></span>`;
}

// ─────────────────────────────────────────────────────────────
// RENDER USER
// ─────────────────────────────────────────────────────────────
function renderUser(user, balance) {
  const name = `${user.first_name || ''} ${user.last_name || ''}`.trim() || user.name || 'User';

  if (user.photo_url) {
    document.getElementById('userAvatar').style.backgroundImage = `url('${user.photo_url}')`;
  } else {
    document.getElementById('userAvatar').textContent = name[0]?.toUpperCase() || '?';
    document.getElementById('userAvatar').style.display = 'flex';
    document.getElementById('userAvatar').style.alignItems = 'center';
    document.getElementById('userAvatar').style.justifyContent = 'center';
    document.getElementById('userAvatar').style.color = '#fff';
    document.getElementById('userAvatar').style.fontWeight = '800';
    document.getElementById('userAvatar').style.fontSize = '22px';
  }

  document.getElementById('userName').textContent    = name;
  document.getElementById('userHandle').textContent  = user.username ? `@${user.username}` : `ID: ${user.tg_id || user.id}`;
  document.getElementById('userBalance').textContent = fmtMoney(balance);
  document.getElementById('userOrders').textContent  = user.total_orders || 0;
  document.getElementById('userSpent').textContent   = fmtMoneyShort(user.total_spent || 0);
  document.getElementById('userBadge').textContent   = user.role === 'admin' ? '👑 Admin' : '⭐ Member';

  STATE.balance = balance;
}

// ─────────────────────────────────────────────────────────────
// BLOCKED STATE
// ─────────────────────────────────────────────────────────────
function renderBlockedState(status, message, contactLink) {
  if (status === 'blocked') {
    document.getElementById('blockedCard').classList.remove('hidden');
    document.getElementById('orderApp').classList.add('hidden');
    document.getElementById('blockedMsg').textContent = message;
    if (contactLink) {
      document.getElementById('contactAdminBtn').href = contactLink;
    }
  }
}

// ─────────────────────────────────────────────────────────────
// MARQUEE / RUNNING TEXT
// ─────────────────────────────────────────────────────────────
function renderMarquee(text) {
  if (!text) return;
  const txt = text.replace(/</g, '&lt;');
  document.getElementById('marqueeText').innerHTML      = txt;
  document.getElementById('marqueeTextClone').innerHTML = txt;
}

// ─────────────────────────────────────────────────────────────
// BANNER SLIDER
// ─────────────────────────────────────────────────────────────
function renderSlider(sliders) {
  const slidesEl = document.getElementById('slides');
  const dotsEl   = document.getElementById('sliderDots');

  if (!sliders || !sliders.length) {
    document.getElementById('sliderCard').classList.add('hidden');
    return;
  }

  slidesEl.innerHTML = sliders.map(s => `
    <div class="slide" style="background-image:url('${escHtml(s.url || s.image_url || '')}')">
      ${s.link && s.link !== '#' ? `<a class="slide-link" href="${escHtml(s.link)}" target="_blank"></a>` : ''}
    </div>
  `).join('');

  dotsEl.innerHTML = sliders.map((_, i) =>
    `<div class="slider-dot ${i === 0 ? 'active' : ''}" data-idx="${i}"></div>`
  ).join('');

  dotsEl.querySelectorAll('.slider-dot').forEach(d => {
    d.addEventListener('click', () => goToSlide(parseInt(d.dataset.idx)));
  });

  startSliderAuto(sliders.length);
}

function goToSlide(idx) {
  const slides = document.getElementById('slides');
  const dots   = document.querySelectorAll('.slider-dot');
  const total  = dots.length;
  if (!total) return;
  STATE.sliderIndex = (idx + total) % total;
  slides.style.transform = `translateX(-${STATE.sliderIndex * 100}%)`;
  dots.forEach((d, i) => d.classList.toggle('active', i === STATE.sliderIndex));
}

function startSliderAuto(total) {
  if (STATE.sliderTimer) clearInterval(STATE.sliderTimer);
  if (total <= 1) return;
  STATE.sliderTimer = setInterval(() => goToSlide(STATE.sliderIndex + 1), SMM_CONFIG.SLIDER_INTERVAL || 4000);
}

// ─────────────────────────────────────────────────────────────
// PLATFORM BUTTONS
// ─────────────────────────────────────────────────────────────
function getPlatforms(categories) {
  const platforms = [{ key: 'all', label: 'All' }];
  const seen = new Set(['all']);
  for (const cat of categories) {
    if (cat.platform_key && !seen.has(cat.platform_key)) {
      seen.add(cat.platform_key);
      platforms.push({ key: cat.platform_key, label: capitalize(cat.platform_key) });
    }
  }
  return platforms;
}

function capitalize(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : s; }

function renderPlatforms() {
  const categories = STATE.homeData.categories || [];
  const platforms  = getPlatforms(categories);
  const grid       = document.getElementById('platformGrid');

  grid.innerHTML = platforms.map(p => `
    <button class="platform-btn ${p.key === STATE.selectedPlatform ? 'active' : ''}" data-key="${p.key}">
      <i class="${getPlatformIcon(p.key)}"></i>
      ${escHtml(p.label)}
    </button>
  `).join('');

  grid.querySelectorAll('.platform-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      STATE.selectedPlatform = btn.dataset.key;
      renderPlatforms();
      renderCategoryDropdown();
      resetServiceDropdown();
    });
  });
}

// ─────────────────────────────────────────────────────────────
// CATEGORY DROPDOWN
// ─────────────────────────────────────────────────────────────
function getCategoriesForPlatform() {
  const cats = STATE.homeData.categories || [];
  if (STATE.selectedPlatform === 'all') return cats;
  return cats.filter(c => c.platform_key === STATE.selectedPlatform);
}

function renderCategoryDropdown() {
  const cats = getCategoriesForPlatform();
  const menu = document.getElementById('catMenu');

  if (!cats.length) {
    menu.innerHTML = '<div class="custom-empty">No categories available.</div>';
    return;
  }

  menu.innerHTML = cats.map(c => `
    <div class="custom-option" data-id="${c.id}">
      <div class="option-icon p-${c.platform_key || 'default'}">
        <i class="${getPlatformIcon(c.platform_key)}"></i>
      </div>
      <div class="option-body">
        <div class="option-title">${escHtml(c.name)}</div>
        <div class="option-sub">${capitalize(c.platform_key || 'General')}</div>
      </div>
    </div>
  `).join('');

  menu.querySelectorAll('.custom-option').forEach(opt => {
    opt.addEventListener('click', () => {
      const id = parseInt(opt.dataset.id, 10);
      selectCategory(id);
      closeAllMenus();
    });
  });
}

function selectCategory(catId) {
  const cats = STATE.homeData.categories || [];
  const cat  = cats.find(c => c.id === catId);
  if (!cat) return;

  document.getElementById('catHidden').value = catId;

  const trigger = document.getElementById('catTriggerContent');
  trigger.innerHTML = `${platformLogoHtml(cat.platform_key)}<span class="trigger-text">${escHtml(cat.name)}</span>`;

  renderServiceDropdown(catId);
}

// ─────────────────────────────────────────────────────────────
// SERVICE DROPDOWN
// ─────────────────────────────────────────────────────────────
function getServicesForCategory(catId) {
  return (STATE.homeData.services || []).filter(s => Number(s.category_id) === Number(catId));
}

function renderServiceDropdown(catId) {
  const services = getServicesForCategory(catId);
  const menu     = document.getElementById('svcMenu');

  if (!services.length) {
    menu.innerHTML = '<div class="custom-empty">No services in this category.</div>';
    resetServiceInfo();
    return;
  }

  menu.innerHTML = services.map(s => `
    <div class="custom-option" data-id="${s.id}">
      <div class="option-icon p-${s.platform_key || 'default'}">
        <i class="${getPlatformIcon(s.platform_key)}"></i>
      </div>
      <div class="option-body">
        <div class="option-title">${escHtml(s.name)}</div>
        <div class="option-sub">
          ID: ${escHtml(s.visible_service_id || String(s.id))} · Min: ${s.min_qty} · Max: ${s.max_qty}
        </div>
        <span class="option-badge">${fmtMoney(s.rate_per_1000)} / 1K</span>
      </div>
    </div>
  `).join('');

  menu.querySelectorAll('.custom-option').forEach(opt => {
    opt.addEventListener('click', () => {
      const id = parseInt(opt.dataset.id, 10);
      selectService(id);
      closeAllMenus();
    });
  });
}

function selectService(svcId) {
  const services = STATE.homeData.services || [];
  const svc      = services.find(s => s.id === svcId);
  if (!svc) return;

  STATE.selectedService = svc;
  document.getElementById('svcHidden').value = svcId;

  const trigger = document.getElementById('svcTriggerContent');
  trigger.innerHTML = `${platformLogoHtml(svc.platform_key)}<span class="trigger-text">${escHtml(svc.name)}</span>`;

  // Set qty min
  const qtyInput = document.getElementById('orderQty');
  qtyInput.min   = svc.min_qty;
  if (!qtyInput.value || Number(qtyInput.value) < svc.min_qty) {
    qtyInput.value = svc.min_qty;
  }

  // Description
  if (svc.description) {
    document.getElementById('descBox').classList.remove('hidden');
    document.getElementById('descText').textContent = svc.description;
  } else {
    document.getElementById('descBox').classList.add('hidden');
  }

  // Custom comments toggle
  const needsComments = svc.needs_custom_comments === 1 || svc.service_type === 'custom_comments';
  document.getElementById('commentsGroup').classList.toggle('hidden', !needsComments);

  updateSummary();
}

function resetServiceDropdown() {
  STATE.selectedService = null;
  document.getElementById('svcHidden').value = '';
  document.getElementById('svcTriggerContent').innerHTML = '<span class="trigger-text">Select Service</span>';
  document.getElementById('svcMenu').innerHTML = '';
  document.getElementById('descBox').classList.add('hidden');
  document.getElementById('commentsGroup').classList.add('hidden');
  resetServiceInfo();
}

function resetServiceInfo() {
  document.getElementById('sumService').textContent = '—';
  document.getElementById('sumMinMax').textContent  = '—';
  document.getElementById('sumRate').textContent    = fmtMoney(0);
  document.getElementById('sumTime').textContent    = '—';
  document.getElementById('sumCharge').textContent  = fmtMoney(0);
}

// ─────────────────────────────────────────────────────────────
// ORDER SUMMARY
// ─────────────────────────────────────────────────────────────
function updateSummary() {
  const svc = STATE.selectedService;
  if (!svc) { resetServiceInfo(); return; }

  const qty    = Number(document.getElementById('orderQty').value || 0);
  const charge = qty > 0 ? (qty * parseFloat(svc.rate_per_1000)) / 1000 : 0;

  document.getElementById('sumService').textContent = svc.name;
  document.getElementById('sumMinMax').textContent  = `${svc.min_qty} / ${svc.max_qty}`;
  document.getElementById('sumRate').textContent    = fmtMoney(svc.rate_per_1000);
  document.getElementById('sumTime').textContent    = svc.avg_time || '—';
  document.getElementById('sumCharge').textContent  = fmtMoney(charge);
}

document.getElementById('orderQty').addEventListener('input', updateSummary);

// ─────────────────────────────────────────────────────────────
// CUSTOM DROPDOWNS — OPEN / CLOSE
// ─────────────────────────────────────────────────────────────
function closeAllMenus() {
  document.querySelectorAll('.custom-select-menu.show').forEach(m => m.classList.remove('show'));
  document.querySelectorAll('.custom-select-trigger.open').forEach(t => t.classList.remove('open'));
}

document.getElementById('catTrigger').addEventListener('click', e => {
  e.stopPropagation();
  const menu   = document.getElementById('catMenu');
  const isOpen = menu.classList.contains('show');
  closeAllMenus();
  if (!isOpen) {
    menu.classList.add('show');
    e.currentTarget.classList.add('open');
  }
});

document.getElementById('svcTrigger').addEventListener('click', e => {
  e.stopPropagation();
  if (!document.getElementById('catHidden').value) {
    showPopup('Category Required', 'Please select a category first.', 'warning');
    return;
  }
  const menu   = document.getElementById('svcMenu');
  const isOpen = menu.classList.contains('show');
  closeAllMenus();
  if (!isOpen) {
    menu.classList.add('show');
    e.currentTarget.classList.add('open');
  }
});

document.addEventListener('click', e => {
  if (!e.target.closest('.custom-select') && !e.target.closest('.search-wrap')) {
    closeAllMenus();
    hideSearchResults();
  }
});

// ─────────────────────────────────────────────────────────────
// GLOBAL SEARCH
// ─────────────────────────────────────────────────────────────
function buildSearchIndex() {
  const services    = STATE.homeData.services    || [];
  const categories  = STATE.homeData.categories  || [];

  STATE.searchIndex = services.map(s => {
    const cat = categories.find(c => c.id === s.category_id) || {};
    return {
      id:           s.id,
      category_id:  s.category_id,
      platform_key: s.platform_key || cat.platform_key || 'default',
      name:         s.name,
      category:     cat.name || '',
      vis_id:       s.visible_service_id || String(s.id),
      search_text:  `${s.name} ${s.visible_service_id || ''} ${cat.name || ''} ${s.id}`.toLowerCase(),
    };
  });
}

const searchInput = document.getElementById('globalSearch');
const searchResultsEl = document.getElementById('searchResults');
const searchClearEl   = document.getElementById('searchClear');

function renderSearchResults(results, query) {
  if (!query) { hideSearchResults(); return; }

  if (!results.length) {
    searchResultsEl.innerHTML = `<div class="search-empty"><i class="fas fa-search" style="display:block;font-size:22px;margin-bottom:6px;opacity:.3"></i>No services found for "${escHtml(query)}"</div>`;
    searchResultsEl.classList.add('show');
    return;
  }

  searchResultsEl.innerHTML = results.slice(0, 20).map(r => `
    <div class="search-item" data-id="${r.id}">
      <div class="search-item-icon platform-logo p-${r.platform_key}">
        <i class="${getPlatformIcon(r.platform_key)}"></i>
      </div>
      <div class="search-item-body">
        <div class="search-item-title">${escHtml(r.name)}</div>
        <div class="search-item-sub">${escHtml(r.category)} · ID: ${escHtml(r.vis_id)}</div>
      </div>
    </div>
  `).join('');

  searchResultsEl.querySelectorAll('.search-item').forEach(item => {
    item.addEventListener('click', () => {
      const r = STATE.searchIndex.find(x => x.id === parseInt(item.dataset.id, 10));
      if (r) pickFromSearch(r);
    });
  });

  searchResultsEl.classList.add('show');
}

function hideSearchResults() { searchResultsEl.classList.remove('show'); }

function pickFromSearch(r) {
  STATE.selectedPlatform = r.platform_key;
  renderPlatforms();
  selectCategory(r.category_id);
  selectService(r.id);
  searchInput.value = `${r.name} (ID: ${r.vis_id})`;
  searchClearEl.classList.add('show');
  hideSearchResults();
}

searchInput.addEventListener('input', () => {
  const q = searchInput.value.trim().toLowerCase();
  searchClearEl.classList.toggle('show', !!q);
  const results = STATE.searchIndex.filter(x => x.search_text.includes(q));
  renderSearchResults(results, q);
});

searchInput.addEventListener('focus', () => {
  const q = searchInput.value.trim().toLowerCase();
  if (q) {
    const results = STATE.searchIndex.filter(x => x.search_text.includes(q));
    renderSearchResults(results, q);
  }
});

searchClearEl.addEventListener('click', () => {
  searchInput.value = '';
  searchClearEl.classList.remove('show');
  hideSearchResults();
});

// ─────────────────────────────────────────────────────────────
// PLACE ORDER
// ─────────────────────────────────────────────────────────────
document.getElementById('placeOrderBtn').addEventListener('click', async () => {
  if (!STATE.initData) {
    showPopup('Telegram Required', 'Please open this app from your Telegram bot.', 'error');
    return;
  }

  const catId   = document.getElementById('catHidden').value;
  const svcId   = document.getElementById('svcHidden').value;
  const link    = document.getElementById('orderLink').value.trim();
  const qty     = Number(document.getElementById('orderQty').value || 0);
  const comments = document.getElementById('customComments').value.trim();
  const svc     = STATE.selectedService;

  if (!catId) { showPopup('Category Missing', 'Please select a category.', 'warning'); return; }
  if (!svcId || !svc) { showPopup('Service Missing', 'Please select a service.', 'warning'); return; }
  if (!link)  { showPopup('Link Required', 'Please enter a valid link.', 'warning'); return; }
  if (!qty || qty < 1) { showPopup('Quantity Required', 'Please enter a valid quantity.', 'warning'); return; }
  if (qty < svc.min_qty) { showPopup('Quantity Too Low', `Minimum quantity is ${svc.min_qty}.`, 'warning'); return; }
  if (qty > svc.max_qty) { showPopup('Quantity Too High', `Maximum quantity is ${svc.max_qty}.`, 'warning'); return; }

  const charge = (qty * parseFloat(svc.rate_per_1000)) / 1000;
  if (charge > STATE.balance) {
    showPopup('Insufficient Balance', `Required: ${fmtMoney(charge)}. Your balance: ${fmtMoney(STATE.balance)}. Please deposit first.`, 'error');
    return;
  }

  if ((svc.needs_custom_comments === 1 || svc.service_type === 'custom_comments') && !comments) {
    showPopup('Comments Required', 'This service requires custom comments.', 'warning');
    return;
  }

  const btn = document.getElementById('placeOrderBtn');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span> Processing...';

  const res = await apiFetch('/api/create-order', {
    method: 'POST',
    body: {
      init_data:       STATE.initData,
      service_id:      svc.id,
      link,
      quantity:        qty,
      custom_comments: comments,
    },
  });

  btn.disabled = false;
  btn.innerHTML = '<i class="fas fa-paper-plane"></i> Place Order';

  if (res.status === 'success') {
    STATE.balance = parseFloat(res.balance || 0);
    document.getElementById('userBalance').textContent = fmtMoney(STATE.balance);
    document.getElementById('orderLink').value  = '';
    document.getElementById('orderQty').value   = svc.min_qty;
    document.getElementById('customComments').value = '';
    updateSummary();
    showPopup('Order Placed! 🎉', `Order #${res.order_id} placed. Charge: ${fmtMoney(res.charge)}. New balance: ${fmtMoney(res.balance)}.`, 'success');
  } else {
    showPopup('Order Failed', res.message || 'Something went wrong. Please try again.', 'error');
  }
});

// ─────────────────────────────────────────────────────────────
// FORCE JOIN OVERLAY
// ─────────────────────────────────────────────────────────────
const joinOverlayEl = document.getElementById('joinOverlay');
const joinListEl    = document.getElementById('joinList');

function showJoinOverlay()  { joinOverlayEl.classList.add('show'); }
function hideJoinOverlay()  { joinOverlayEl.classList.remove('show'); }

function renderJoinChannels(channels) {
  if (!channels.length) {
    joinListEl.innerHTML = '<div class="search-empty">All channels joined ✅</div>';
    return;
  }

  joinListEl.innerHTML = channels.map(ch => `
    <div class="join-item">
      <div class="join-item-left">
        <div class="join-logo"><i class="fab fa-telegram-plane"></i></div>
        <div class="join-meta">
          <div class="join-title">${escHtml(ch.title || 'Telegram Channel')}</div>
          <div class="join-sub">${escHtml(ch.channel_username || '')}</div>
        </div>
      </div>
      <a href="${escHtml(ch.invite_link || `https://t.me/${(ch.channel_username || '').replace('@', '')}`)}"
         target="_blank" class="join-btn">
        <i class="fas fa-arrow-right"></i> Join
      </a>
    </div>
  `).join('');
}

document.getElementById('joinCheckBtn').addEventListener('click', async () => {
  const btn = document.getElementById('joinCheckBtn');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span> Checking...';

  const res = await apiFetch('/api/check-join', {
    method: 'POST',
    body: { init_data: STATE.initData, force_refresh: 1 },
  });

  btn.disabled = false;
  btn.innerHTML = '<i class="fas fa-rotate-right"></i> Check Again';

  if (res.status === 'success') {
    if (res.all_joined) {
      hideJoinOverlay();
    } else {
      renderJoinChannels(res.channels || []);
    }
  }
});

async function checkForceJoin(forceRefresh = false) {
  const res = await apiFetch('/api/check-join', {
    method: 'POST',
    body: { init_data: STATE.initData, force_refresh: forceRefresh ? 1 : 0 },
  });

  if (res.status !== 'success') return;

  renderJoinChannels(res.channels || []);
  if (!res.all_joined && !res.cached) showJoinOverlay();
}

// ─────────────────────────────────────────────────────────────
// TELEGRAM ONLY GATE
// ─────────────────────────────────────────────────────────────
function showTelegramGate(message) {
  document.body.innerHTML = `
    <div class="tg-gate">
      <div class="tg-gate-card">
        <div class="tg-gate-icon"><i class="fas fa-shield-halved"></i></div>
        <h2 class="tg-gate-title">Telegram Only</h2>
        <p class="tg-gate-text">${escHtml(message || 'Please open this app from your Telegram bot.')}</p>
      </div>
    </div>
  `;
}

// ─────────────────────────────────────────────────────────────
// KITE CELEBRATION (order success)
// ─────────────────────────────────────────────────────────────
function spawnKites() {
  const colors = ['#2563eb','#0ea5e9','#22c55e','#f59e0b','#ef4444','#7c3aed'];
  for (let i = 0; i < 12; i++) {
    setTimeout(() => {
      const el  = document.createElement('div');
      el.className = 'kite-particle';
      const size = 8 + Math.random() * 12;
      el.style.cssText = `
        width:${size}px;height:${size}px;
        border-radius:50%;
        background:${colors[Math.floor(Math.random() * colors.length)]};
        left:${Math.random() * 100}vw;
        bottom:0;
        animation:kiteFly ${2 + Math.random() * 2}s ease-out forwards;
      `;
      document.body.appendChild(el);
      setTimeout(() => el.remove(), 4000);
    }, i * 100);
  }
}

// Override showPopup for success to also spawn kites
const _origShowPopup = showPopup;
window.showPopup = function(title, message, type, onAction) {
  if (type === 'success') spawnKites();
  _origShowPopup(title, message, type, onAction);
};

// ─────────────────────────────────────────────────────────────
// INIT
// ─────────────────────────────────────────────────────────────
(async function init() {
  // Must be opened from Telegram
  if (!STATE.tg || !STATE.initData) {
    showTelegramGate('This app must be opened from the Telegram bot.\n\nPlease use the bot to access the panel.');
    return;
  }

  // 1. Login / register
  const loginRes = await apiFetch('/api/login', {
    method: 'POST',
    body: {
      init_data: STATE.initData,
      ref: new URLSearchParams(STATE.tg.initDataUnsafe?.start_param || '').get('ref') || '',
    },
  });

  if (loginRes.status === 'blocked') {
    // Show blocked state before home data
    document.getElementById('blockedCard').classList.remove('hidden');
    document.getElementById('orderApp').classList.add('hidden');
    document.getElementById('blockedMsg').textContent = loginRes.message || 'Your account has been blocked.';
    const contactBtn = document.getElementById('contactAdminBtn');
    if (loginRes.admin_contact) contactBtn.href = loginRes.admin_contact;
    // Still render basic user from tg
    const tgUser = STATE.tg.initDataUnsafe?.user || {};
    renderUser({ ...tgUser, tg_id: tgUser.id, total_orders: 0, total_spent: 0 }, 0);
    return;
  }

  if (loginRes.status !== 'success') {
    showTelegramGate(loginRes.message || 'Login failed. Please reopen from Telegram bot.');
    return;
  }

  STATE.user = loginRes.user;
  STATE.currency = '৳';
  renderUser(loginRes.user, loginRes.user.balance);

  // 2. Load home data
  const homeRes = await apiFetch('/api/home-data', {
    method: 'POST',
    body: { init_data: STATE.initData },
  });

  if (homeRes.status === 'success') {
    STATE.homeData = homeRes;
    STATE.currency = homeRes.settings?.currency_symbol || '৳';

    // Update balance from home data (fresh)
    STATE.balance = parseFloat(homeRes.user_balance || loginRes.user.balance || 0);
    document.getElementById('userBalance').textContent = fmtMoney(STATE.balance);

    renderBlockedState(homeRes.user_status, homeRes.blocked_message, homeRes.admin_contact_link);
    renderMarquee(homeRes.running_text);
    renderSlider(homeRes.sliders || []);
    renderPlatforms();
    renderCategoryDropdown();
    buildSearchIndex();
  }

  // 3. Force join check (background, 5ms delay)
  setTimeout(() => checkForceJoin(false), 5);
})();
